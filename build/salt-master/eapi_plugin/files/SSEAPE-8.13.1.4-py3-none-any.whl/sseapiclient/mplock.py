# coding: utf-8
"""
Multiprocess lock
"""

#
# Copyright (C) 2023 VMware, Inc.
#

# Import Python libs
import contextlib
import fcntl
import logging
import os

log = logging.getLogger(__name__)

LOCK_COUNT = 0


@contextlib.contextmanager
def multiprocess_lock(dirpath):
    """
    Context manager for a file-based exclusive lock for unrelated processes.
    Set dirpath to the path of a directory, which will be created if it doesn't
    exist.
    """
    global LOCK_COUNT
    try:
        os.makedirs(dirpath, exist_ok=True)
    except OSError as exc:
        log.error("Could not initialize lock: %s: %s", dirpath, exc)
        raise

    try:
        if LOCK_COUNT == 0:
            dirfd = os.open(dirpath, os.O_RDONLY)
            fcntl.flock(dirfd, fcntl.LOCK_EX)
        LOCK_COUNT += 1
        yield
    finally:
        LOCK_COUNT -= 1
        if LOCK_COUNT == 0:
            os.close(dirfd)  # releases lock
