# coding: utf-8

import base64
import datetime
import errno
import gzip
import http.cookiejar
import json
import logging
import os
import re
import socket
import ssl
import tempfile
import time
import timeit
import urllib.error
import urllib.parse
import urllib.request
import uuid

# isort:skip_file

# Import SSEApiClient libs
import sseapiclient.mplock
import sseapiclient.serialize
from sseapiclient.exc import (
    AuthKeyInvalidFailure,
    AuthKeyNotAcceptedFailure,
    AuthKeyRotationFailure,
    NotConnectable,
    RequestFailure,
    TimeoutFailure,
)

# Import 3rd party libs
import jwt  # pylint: disable=wrong-import-order

HAS_PYCRYPTODOME = False
try:
    import Cryptodome.Random
    from Cryptodome.PublicKey import RSA
    from Cryptodome.Cipher import PKCS1_OAEP

    HAS_PYCRYPTODOME = True
except ImportError:
    pass

log = logging.getLogger(__name__)

if HAS_PYCRYPTODOME:
    Cryptodome.Random.atfork()
else:
    log.info("Key authentication disabled due to missing pycryptodomex")

DEFAULT_CSP_URL = "https://console.cloud.vmware.com"

ALL_OAUTH_CSP_TOKEN_CLAIMS = [
    "sub",
    "iss",
    "context_name",
    "authorization_details",
    "context",
    "perms",
    "exp",
    "iat",
    "jti",
]

ALL_USER_API_CSP_TOKEN_CLAIMS = [
    "sub",
    "iss",
    "context_name",
    "authorization_details",
    "context",
    "perms",
    "exp",
    "iat",
    "jti",
    "username",
]


def _get_riq_jid(body):
    log.debug("@#@# get_riq_jid")
    resmethod = riq = jid = None
    if not body:
        return (
            resmethod,
            riq,
            jid,
        )
    if body and "resource" in body and "method" in body:
        resmethod = body["resource"] + "." + body["method"]
    else:
        resmethod = "none"
    if body and "riq" in body:
        riq = body["riq"]
    if body:
        if "jid" in body:
            jid = body["jid"]
        elif "kwargs" in body and "jid" in body["kwargs"]:
            jid = body["kwargs"].get("jid", "none")
        else:
            jid_search = re.search(r"2021\d+", str(body))
            if jid_search:
                jid = jid_search.group(0)
            else:
                jid = "none"
    return (
        resmethod,
        riq,
        jid,
    )


class ResponseSaverErrorProcessor(urllib.request.HTTPErrorProcessor, object):
    """
    The default HTTPErrorProcessor hides the response but we kinda sorta need it
    """

    def __init__(self, http_client):
        self.http_client = http_client

    def http_response(self, request, response):
        self.http_client._error_response = response
        return super(ResponseSaverErrorProcessor, self).http_response(request, response)

    https_response = http_response


class HTTPClient(object):
    """
    A synchronous http client for use with the SaltStack Enterprise API.
    Intended for use by the APIClient class rather than instantiated directly.
    """

    def __init__(
        self,
        server,
        username=None,
        password=None,
        config_name="internal",
        csp_url=None,
        csp_org_id=None,
        csp_client_id=None,
        csp_client_secret=None,
        csp_api_token=None,
        timeout=60,
        pubkey_path=None,
        master_id=None,
        cookies_path=None,
        json_encoder=None,
        rpc_api_version=None,
        ssl_key=None,
        ssl_cert=None,
        ssl_validate_cert=True,
        ssl_context=None,
        compression=True,
    ):
        self.server = server.rstrip("/")
        self.username = username
        self.password = password
        self.config_name = config_name
        self._use_jwt = True if (username and password) or pubkey_path else False

        self.csp_org_id = csp_org_id
        self.csp_client_id = csp_client_id
        self.csp_url = csp_url.rstrip("/") if csp_url else DEFAULT_CSP_URL
        self.csp_client_secret = csp_client_secret
        self._csp_access_token_valid_until = 0
        self._csp_api_token = csp_api_token
        self._use_csp = bool(
            (
                self._csp_api_token
                or (csp_url and csp_org_id and csp_client_id and csp_client_secret)
            )
            or False
        )
        self._csp_access_token = None
        self._validate_csp_args()

        self.timeout = timeout

        if pubkey_path and not master_id:
            raise RuntimeError("master_id must be provided with sseapi_pubkey_path")
        self.master_id = master_id

        self.pubkey_path = pubkey_path
        if self.pubkey_path:
            self.pubkey_dir = os.path.dirname(self.pubkey_path)
            self.pubkey = self._read_auth_key()
        else:
            self.pubkey_dir = None
            self.pubkey = None

        if cookies_path is None:
            ofh, cookies_path = tempfile.mkstemp()
            os.close(ofh)
            os.unlink(cookies_path)
        self.cookies = http.cookiejar.LWPCookieJar(filename=cookies_path)

        self.json_encoder = json_encoder
        self.rpc_api_version = rpc_api_version

        self.ssl_key = ssl_key
        self.ssl_cert = ssl_cert
        self.ssl_validate_cert = ssl_validate_cert
        if ssl_context:
            if not isinstance(ssl_context, ssl.SSLContext):
                raise RuntimeError("ssl_context must be an instance of ssl.SSLContext")
            if ssl_key or ssl_cert:
                raise RuntimeError(
                    "When passing ssl_context, none of the other ssl options should be passed"
                )
        self.ssl_context = ssl_context

        self.compression = compression

        self._xsrf_token = None
        self._jwt = None
        self._authenticated = False
        self._known_raisins = set()
        self._last_auth_request_time = 0
        self._error_response = None

    def __repr__(self):
        return "<{cls} {desc}>".format(
            cls=self.__class__.__name__, desc=self.describe()
        )

    def _validate_csp_args(self):
        """
        Add some helpful validation of CSP args that were supplied to the monolithic constructor of this class
        :return:
        """
        if not self.username and not self._use_csp:
            raise RuntimeError(
                'At least one of "username" or "csp_*" arguments are required for authz.'
            )

    def _make_url(self, url, params=None):
        """
        Format a raas url. Optional query args can be passed in params.
        """
        url = urllib.parse.urljoin(self.server, url)
        if params:
            url = "{}?{}".format(url, urllib.parse.urlencode(params))
        return url

    def _make_opener(self, url):
        """
        Make a urllib request opener that can handle cookies and optional ssl.
        """
        if url.startswith("https:"):
            if self.ssl_context:
                context = self.ssl_context
            else:
                if self.ssl_validate_cert:
                    context = ssl.create_default_context()
                else:
                    context = ssl._create_unverified_context()
                if self.ssl_cert and self.ssl_key:
                    context.load_cert_chain(self.ssl_cert, self.ssl_key)
            prot_handler = urllib.request.HTTPSHandler(context=context)
        else:
            prot_handler = urllib.request.HTTPHandler()
        cookie_handler = urllib.request.HTTPCookieProcessor(self.cookies)
        error_handler = ResponseSaverErrorProcessor(self)
        return urllib.request.build_opener(prot_handler, cookie_handler, error_handler)

    def _build_request(self, url, method, body=None, jwt=None):
        """
        Build the request object
        """
        if body is not None and not isinstance(body, bytes):
            body = self.json_dumps(body).encode()
        request = urllib.request.Request(url, method=method, data=body)
        if self._xsrf_token:
            request.add_header("X-XSRFToken", self._xsrf_token)

        if self._use_csp:
            if not self._use_jwt:
                request.add_header(
                    "Authorization", "Bearer {}".format(self._csp_access_token)
                )

            # With hybrid auth for salt-master, eAPI will send both JWT (in Authorization: JWT {} header)
            # and CSP access-token (csp-auth-token header). saas-controller will validate the csp-auth-token in
            # csp-auth-token header and pass it on to raas, which will validate both csp-auth-token header and
            # Authorization JWT header.
            request.add_header("csp-auth-token", self._csp_access_token)

        if jwt is None:
            jwt = self._jwt
        if jwt:
            request.add_header("Authorization", "JWT {}".format(jwt))
        if self.rpc_api_version:
            request.add_header("X-RaaS-RPC-Version", self.rpc_api_version)
        if self.compression:
            request.add_header("Accept-Encoding", "gzip")
        self.cookies.add_cookie_header(request)
        return request

    def _refresh_csp_access_token(self):
        """
        Refresh CSP tokens
        """
        if not self._use_csp:
            return
        if self._csp_access_token_valid_until > time.time():
            return
        if self._csp_access_token_valid_until:
            log.info(
                "Current CSP access token expired. Refreshing. Valid Until = %s, Now = %s",
                self._csp_access_token_valid_until,
                time.time(),
            )
        self._set_csp_access_token()

        required_token_claims = (
            ALL_USER_API_CSP_TOKEN_CLAIMS
            if self._csp_api_token
            else ALL_OAUTH_CSP_TOKEN_CLAIMS
        )
        jwt_dict = jwt.decode(
            jwt=self._csp_access_token,
            options={"require": required_token_claims, "verify_signature": False},
        )

        # Set expiry to 90% of token validity time, relative to current time.
        self._csp_access_token_valid_until = (
            time.time() + (jwt_dict["exp"] - jwt_dict["iat"]) * 0.9
        )
        log.info(
            "CSP token refresh successful. Valid Until = %s",
            self._csp_access_token_valid_until,
        )

    def _get_oauth_app_auth_flow_headers_and_body(self):
        url = self.csp_url + "/csp/gateway" + "/am/api/auth/authorize"
        data = {"orgId": self.csp_org_id, "grant_type": "client_credentials"}
        creds = base64.b64encode(
            "{csp_client_id}:{csp_client_secret}".format(
                csp_client_id=self.csp_client_id,
                csp_client_secret=self.csp_client_secret,
            ).encode()
        ).decode("utf-8")
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": "Basic " + creds,
        }

        return url, headers, data

    def _get_user_auth_flow_headers_and_body(self):
        url = self.csp_url + "/csp/gateway" + "/am/api/auth/api-tokens/authorize"
        data = {"api_token": self._csp_api_token}
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        return url, headers, data

    def _set_csp_access_token(self):
        """
        This workflow is for both (1) OAuth app and (2) User API token flow
        (see https://confluence.eng.vmware.com/display/SBUS/OAuth+App+and+User+API+Token+flow)
        :return:
        """
        if self._csp_api_token:
            url, headers, data = self._get_user_auth_flow_headers_and_body()
        else:
            url, headers, data = self._get_oauth_app_auth_flow_headers_and_body()

        if self.compression:
            headers["Accept-Encoding"] = "gzip"
        request = urllib.request.Request(
            url,
            method="POST",
            headers=headers,
            data=urllib.parse.urlencode(data).encode("ascii"),
        )
        opener = self._make_opener(url)
        try:
            response = opener.open(request, timeout=self.timeout)
            token = self._decode_body(response)
            self._csp_access_token = token["access_token"]
            log.debug("CSP Access token set successful")
        except urllib.error.HTTPError as exc:
            log.error("Error obtaining access token - %s", exc)
            raise NotConnectable(exc)
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, socket.timeout):
                raise TimeoutFailure("Request timed out")
            raise NotConnectable(exc.reason)
        except ssl.SSLError as exc:
            try:
                exc_text = exc.reason
            except AttributeError:
                exc_text = str(exc)
            raise NotConnectable(exc_text)
        except socket.timeout as exc:
            raise TimeoutFailure("Request timed out")
        except OSError as exc:
            if exc.errno == errno.ECONNRESET:
                if isinstance(exc, OSError):
                    raise NotConnectable(exc.strerror)
                else:
                    raise NotConnectable(exc)
            raise

    def _save_auth_key(self, keydata):
        """
        Write the auth key to the filesystem
        """
        ret = False
        orig_mask = os.umask(0o177)
        try:
            with open(self.pubkey_path, "w") as fh:
                fh.write(keydata)
            ret = True
            log.info("Saved auth key to %s", self.pubkey_path)
        except Exception as exc:  # pylint: disable=broad-except
            log.error("Could not save auth key to %s: %s", self.pubkey_path, exc)
        finally:
            os.umask(orig_mask)
        return ret

    def _read_auth_key(self):
        """
        Read the auth key from the filesystem and import it
        """
        pubkey = None
        try:
            with open(self.pubkey_path, "r") as fh:
                keydata = fh.read()
            pubkey = RSA.import_key(keydata)
            log.info("Read auth key from %s", self.pubkey_path)
        except Exception as exc:  # pylint: disable=broad-except
            log.info("Could not read auth key: %s", exc)
        return pubkey

    def _request_master_key(self):
        """
        Request a new authentication key from SSC
        """
        # Before requesting a new key from raas, read the current key from the
        # filesystem. If it's different from the current one, assume that it
        # was updated by another process and use it instead of requesting
        # another one.
        with sseapiclient.mplock.multiprocess_lock(self.pubkey_dir):
            fs_pubkey = self._read_auth_key()
            if fs_pubkey and (not self.pubkey or self.pubkey != fs_pubkey):
                self.pubkey = fs_pubkey
                return

            log.info("Requesting a new auth key")
            try:
                self.init_xsrf()
                body = {
                    "resource": "master",
                    "method": "request_master_key",
                    "kwarg": {
                        "master_id": self.master_id,
                    },
                }
                response = self.fetch(
                    "/rpc",
                    method="POST",
                    body=body,
                    jwt=False,
                    retry_on_auth_failure=False,
                )
                if response.get("error", False):
                    errorcode = response["error"].get("code", 0)
                    message = response["error"].get("message", "Unknown error message")
                    excmsg = str(errorcode) + ": " + message
                    raise AuthKeyRotationFailure(excmsg)
            except Exception as exc:  # pylint: disable=broad-except
                log.error("Auth key request failed: %s", exc)
                return

            if "pubkey" in response["ret"] and "fingerprint" in response["ret"]:
                if self._save_auth_key(response["ret"]["pubkey"]):
                    log.info("Auth key fingerprint: %s", response["ret"]["fingerprint"])
                    self.pubkey = self._read_auth_key()
            else:
                log.error(
                    "Auth key request failed: pubkey missing from return: %s",
                    response["ret"],
                )

    def rotate_master_key(self):
        """
        Rotate the SSC authentication key
        """
        with sseapiclient.mplock.multiprocess_lock(self.pubkey_dir):
            log.info("Rotating auth key")
            try:
                self.init_xsrf()
                body = {
                    "resource": "master",
                    "method": "rotate_master_key",
                    "kwarg": {
                        "master_id": self.master_id,
                    },
                }
                response = self.fetch("/rpc", method="POST", body=body)
                if response.get("error", False):
                    errorcode = response["error"].get("code", 0)
                    message = response["error"].get("message", "Unknown error message")
                    excmsg = str(errorcode) + ": " + message
                    raise AuthKeyRotationFailure(excmsg)

            except Exception as exc:  # pylint: disable=broad-except
                log.info("Auth key rotation failed: %s", exc)
                raise

            if "pubkey" in response["ret"] and "fingerprint" in response["ret"]:
                if self._save_auth_key(response["ret"]["pubkey"]):
                    log.info("Auth key fingerprint: %s", response["ret"]["fingerprint"])
                    self.authenticate()
            else:
                log.error(
                    "Auth key rotation failed: pubkey missing from return: %s",
                    response["ret"],
                )
                raise RuntimeError(
                    "Pubkey missing from return: {}".format(response["ret"])
                )

    def _encrypt_message(self, data):
        """
        Encrypt a message to send to SSC
        """
        data = self.json_dumps(data).encode()
        cipher = PKCS1_OAEP.new(self.pubkey)
        emsg = cipher.encrypt(data)
        return base64.b64encode(emsg).decode()

    def get_master_jwt(self, test=False):
        """
        Get a jwt from SSC
        """
        try:
            data = {
                "created": datetime.datetime.utcnow().isoformat() + "Z",
                "master_id": self.master_id,
            }
            emsg = self._encrypt_message(data)
        except Exception as exc:  # pylint: disable=broad-except
            raise AuthKeyInvalidFailure("Encryption failed")

        log.debug("Requesting jwt using auth key")
        self.init_xsrf()
        body = {
            "resource": "master",
            "method": "get_master_jwt",
            "kwarg": {
                "master_id": self.master_id,
                "encrypted_message": emsg,
                "test": test,
            },
        }
        response = self.fetch(
            "/rpc", method="POST", body=body, jwt=False, retry_on_auth_failure=False
        )

        if response.get("error"):
            log.info(
                "Failed to get jwt: ignoring invalid auth key: %s", response["error"]
            )
            raise AuthKeyInvalidFailure(response["error"])

        ret = response.get("ret", {})
        state = ret.get("state")
        if state == "pending":
            log.info("Waiting for auth key to be accepted")
            raise AuthKeyNotAcceptedFailure("Key is pending")
        if state != "accepted":
            raise AuthKeyNotAcceptedFailure("Invalid key state: {}".format(state))

        jwt = ret.get("jwt")
        if not jwt:
            raise RuntimeError("JWT missing from return: {}".format(ret))

        log.debug("Auth key verified, got new jwt")
        return jwt

    def describe(self):
        """
        Return a string showing some important parameters
        """
        auth_attrs = []
        if self.pubkey_path:
            auth_attrs.append("pubkey")
        elif self.password:
            auth_attrs.append("passwd")
        if self._use_csp:
            auth_attrs.append("csp")

        fmt = (
            "server={server!r} username={username!r} config_name={config_name!r} "
            "rpc_api_version={apiver!r} authenticated={auth!r} auth_attrs={auth_attrs} "
            "compression={gzip!r}"
        )
        return fmt.format(
            server=self.server,
            username=self.username,
            config_name=self.config_name,
            apiver=self.rpc_api_version,
            auth=self._authenticated,
            auth_attrs=",".join(auth_attrs),
            gzip=self.compression,
        )

    def json_dumps(self, data):
        return sseapiclient.serialize.json_dumps(data, cls=self.json_encoder)

    def init_xsrf(self):
        if self._xsrf_token is None:
            # Try to get the XSRF token header
            log.debug("Refreshing XSRF token")
            self.fetch("/account/login")
            if self._xsrf_token is None:
                # This means that the XSRF token is disabled
                log.debug("XSRF token is disabled on the server")
                self._xsrf_token = False

    def password_auth(self):
        """
        Authenticate using username and password and return the jwt
        """
        log.debug("Authenticating with password")
        jwt = None
        body = {
            "username": self.username,
            "password": self.password,
            "config_name": self.config_name,
            "token_type": "jwt",
        }

        response = self.fetch(
            "/account/login",
            method="POST",
            body=body,
            jwt=False,
            retry_on_auth_failure=False,
        )
        if (
            isinstance(response, dict)
            and response.get("attributes", {}).get("username", None) == self.username
        ):
            jwt = response.get("jwt")
        return jwt

    def key_auth(self):
        """
        Authenticate using a key and return the jwt
        """
        jwt = None
        if HAS_PYCRYPTODOME:
            log.debug("Authenticating with key")
            try:
                jwt = self.get_master_jwt(test=False)
            except AuthKeyNotAcceptedFailure as exc:
                log.info("Authentication failed: auth key not accepted: %s", exc)
            except AuthKeyInvalidFailure as exc:
                log.info("Authentication failed: key is invalid: %s", exc)
                self._request_master_key()
                # If the key is pending now it cannot be used for
                # authentication, and the following call to request a jwt will
                # log a message that the key is not yet accepted
                jwt = self.get_master_jwt(test=False)
            except Exception as exc:  # pylint: disable=broad-except
                log.info("Authentication failed: %s", exc)
        else:
            log.error("Key authentication disabled due to missing pycryptodomex")
        return jwt

    def validate_jwt(self, jwt):
        """
        Ask raas if a jwt is valid
        """
        log.debug("Validating jwt")
        valid = False
        if jwt:
            try:
                response = self.fetch(
                    "/account/info", jwt=jwt, retry_on_auth_failure=False
                )
                if (
                    isinstance(response, dict)
                    and response.get("attributes", {}).get("username", None)
                    == self.username
                ):
                    valid = True
            except Exception as exc:  # pylint: disable=broad-except
                log.info("Could not validate jwt: %s", exc)
        return valid

    def _refresh_jwt(self):
        log.debug("Refreshing jwt")
        if self.pubkey_path:
            self._jwt = self.key_auth()
        elif self.password:
            self._jwt = self.password_auth()
        self._last_auth_request_time = time.time()

    def authenticate(self):
        self._authenticated = False
        self.init_xsrf()

        if self._use_jwt and not self.validate_jwt(self._jwt):
            self._refresh_jwt()

        self._authenticated = bool(
            (
                self._use_csp
                and self._csp_access_token
                and ((self._use_jwt and self._jwt) or not self._use_jwt)
            )
            or (not self._use_csp and self._use_jwt and self._jwt)
        )

    def _handle_auth_error(self, retry_on_auth_failure):
        """
        If the response is a 401, 403 or 504 error and retry_on_auth_failure is
        True, prepare to retry the request by refreshing the JWT or the XSRF
        token.

        Return True if the caller should retry the request, False otherwise.
        """
        response = self._error_response
        if response is None or response.code not in (401, 403, 504):
            return False

        self._authenticated = False

        if response.code == 504:
            # Gateway timeout
            return retry_on_auth_failure

        if response.code == 401:
            # Unauthorized: no auth header, invalid auth header, or expired jwt
            if retry_on_auth_failure:
                self.authenticate()
            if not self._authenticated:
                # Log at debug level here since the failure may not be serious,
                # e.g. in the case of an expired jwt. An exception will be
                # raised to the caller for logging.
                log.debug("Failed to authenticate: %s", response.msg)
            return self._authenticated

        if response.code == 403:
            # Forbidden: possibly due to missing xsrf token
            # RaaS Versions >= 8.3 set the header, lower versions use the response message.
            if (
                "missing xsrf" in response.msg.lower()
                or "missing xsrf"
                in response.headers.get("X-XSRFToken-Missing", "").lower()
            ):
                self._xsrf_token = None
                self.cookies.clear()
                if retry_on_auth_failure:
                    self.authenticate()
                    return self._authenticated
            raise RequestFailure(code=response.code, message=response.msg)

    def _decode_body(self, response):
        """
        JSON decode a response body
        """
        if response.code == 204:
            return response.body

        try:
            if response.info().get("Content-Encoding") == "gzip":
                body = gzip.decompress(response.read())
            else:
                body = response.read()
        except ssl.SSLError as exc:
            try:
                exc_text = exc.reason
            except AttributeError:
                exc_text = str(exc)
            raise NotConnectable(exc_text)

        try:
            if response.info().get("Content-Type") == "application/octet-stream":
                return body
            return json.loads(body.decode("utf-8"))
        except ValueError:
            log.debug("Failed to decode JSON from: %r", body)
            return body

    @property
    def last_auth_request_time(self):
        return self._last_auth_request_time

    def fetch(
        self,
        url,
        method="GET",
        body=None,
        timeout=None,
        jwt=None,
        retry_on_auth_failure=True,
        params=None,
    ):
        """
        Issue the request to the server
        """
        if self._use_csp:
            log.debug("Using CSP with access token")
            # Check and refresh CSP access token
            self._refresh_csp_access_token()

        url = self._make_url(url, params)
        opener = self._make_opener(url)
        request = self._build_request(url, method, body=body, jwt=jwt)

        resmethod = riq = jid = None
        jidlist = []
        if isinstance(body, dict):
            (resmethod, riq, jid) = _get_riq_jid(body)
            log.debug(
                "Sending %s request (id %x, resource.method %s, riq %s, jid %s) to %s",
                request.get_method(),
                id(request),
                resmethod,
                riq,
                jid,
                request.get_full_url(),
            )
            jidlist.append(
                (
                    resmethod,
                    riq,
                    jid,
                )
            )
        elif isinstance(body, list):
            for bentry in body:
                (resmethod, riq, jid) = _get_riq_jid(bentry)
                log.debug(
                    "Batching %s request (id %x, resource.method %s, riq %s, jid %s) to %s",
                    request.get_method(),
                    id(request),
                    resmethod,
                    riq,
                    jid,
                    request.get_full_url(),
                )
                jidlist.append(
                    (
                        resmethod,
                        riq,
                        jid,
                    )
                )
        else:
            log.debug(
                "Sending %s request (id %x) to %s",
                request.get_method(),
                id(request),
                request.get_full_url(),
            )
            jidlist.append(
                (
                    "none",
                    "none",
                    "none",
                )
            )

        if timeout is None:
            timeout = self.timeout
        start = timeit.default_timer()
        try:
            response = opener.open(request, timeout=timeout)
            elapsed = timeit.default_timer() - start
            log.debug(response.info())
            if response.info().get("Accept-Encoding") and "gzip" in response.info().get(
                "Accept-Encoding"
            ):
                if self.disable_gzip_compression:
                    self.compression = False
                else:
                    self.compression = True
            for j in jidlist:
                (resmethod, riq, jid) = j
                log.debug(
                    "The %s request (id: %x, resource.method %s, riq %s, jid %s) to %s, finished in %.2fms. HTTP Code: %s",
                    request.get_method(),
                    id(request),
                    resmethod,
                    riq,
                    jid,
                    request.get_full_url(),
                    1000 * elapsed,
                    response.code,
                )
        except ValueError as exc:
            if "Invalid header value" in str(exc) and any(
                s in str(exc) for s in ("JWT ", "Bearer ")
            ):
                log.warning("Discarding corrupt jwt: %s", exc)
                self.authenticate()
            raise RequestFailure(code=401, message="Corrupt jwt")
        except urllib.error.HTTPError as exc:
            elapsed = timeit.default_timer() - start
            for j in jidlist:
                (resmethod, riq, jid) = j
                log.debug(
                    "The %s request (id: %x, resource.method %s, riq %s, jid %s) to %s finished in %.2fms and returned an error: %s %s",
                    request.get_method(),
                    id(request),
                    resmethod,
                    riq,
                    jid,
                    request.get_full_url(),
                    1000 * elapsed,
                    exc.code,
                    exc.reason,
                )
            if self._handle_auth_error(retry_on_auth_failure):
                log.debug(
                    "Retrying %s request (id: %x) to %s",
                    request.get_method(),
                    id(request),
                    request.get_full_url(),
                )
                return self.fetch(
                    url,
                    method=method,
                    body=body,
                    timeout=timeout,
                    retry_on_auth_failure=False,
                    params=params,
                )
            raise RequestFailure(code=exc.code, message=exc.reason)
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, socket.timeout):
                raise TimeoutFailure("Request timed out")
            raise NotConnectable(exc.reason)
        except ssl.SSLError as exc:
            try:
                exc_text = exc.reason
            except AttributeError:
                exc_text = str(exc)
            raise NotConnectable(exc_text)
        except socket.timeout as exc:
            raise TimeoutFailure("Request timed out")
        except OSError as exc:
            if exc.errno == errno.ECONNRESET:
                if isinstance(exc, OSError):
                    raise NotConnectable(exc.strerror)
                else:
                    raise NotConnectable(exc)
            raise

        self.cookies.extract_cookies(response, request)
        for cookie in self.cookies:
            if cookie.name == "_xsrf":
                self._xsrf_token = cookie.value
                break

        # Check the raas instance id against known raisins. If this is a
        # formerly unknown instance, update the last authentication request
        # time.
        try:
            raas_instance_id = response.headers["RaaS-Instance-ID"]
            raas_instance_id = str(uuid.UUID(raas_instance_id))
            if raas_instance_id not in self._known_raisins:
                log.debug("New raas instance detected: %s", raas_instance_id)
                self._last_auth_request_time = time.time()
                self._known_raisins.add(raas_instance_id)
        except (KeyError, TypeError, ValueError):
            pass
        return self._decode_body(response)
