#!/usr/bin/env python3
# coding: utf-8

# Export or import raas resources
#
# Notes:
#
# - Newly imported RBAC resources will be owned by the authenticated user
#   running the import.
# - Permissions on individual resources are preserved.

# XXX could do:
# - auth settings
# - sec
#   - policies with benchmarks, checks, exclusions, variables, schedule, exemptions

import argparse
import base64
import copy
import json
import logging
import os.path
import sys
import sseapiclient

log = logging.getLogger(os.path.basename(sys.argv[0]))


class BaseHandler:
    paginated = True
    priority = 100

    def __init__(self, config=None):
        self.config = config

    def export(self, client, query_args):
        pass


class MasterHandler(BaseHandler):
    paginated = False
    priority = 50

    def export(self, client, query_args):
        results = []
        ret = client.api.master.get_master_grains(**query_args).ret
        for master_id in ret:
            results.append(("master:{}".format(master_id), json.dumps(ret[master_id])))
        return results


class MinionHandler(BaseHandler):
    priority = 51

    def export(self, client, query_args):
        results = []
        ret = client.api.minions.get_minion_details(**query_args).ret
        for entry in ret["results"]:
            results.append(("minion:{}".format(entry["id"]), json.dumps(entry)))
        return results


class TgtHandler(BaseHandler):
    priority = 30

    def export(self, client, query_args):
        skip_uuids = [
            tgt["uuid"] for tgt in client.api_constants["target-groups"].values()
        ]
        results = []
        ret = client.api.tgt.get_target_group(**query_args).ret
        for entry in ret["results"]:
            tgt_uuid = entry.pop("uuid")
            if tgt_uuid in skip_uuids:
                continue
            entry["pillar_uuids"] = entry.pop("pillars")
            if not entry["desc"]:
                entry.pop("desc")
            results.append(("tgt:{}".format(tgt_uuid), json.dumps(entry)))
        return results

    def exists(self, client, tgt_uuid):
        ret = client.api.tgt.get_target_group(tgt_uuid=tgt_uuid).ret
        return ret["results"] != []

    def import_one(self, client, wait_for_match, tgt_uuid, data):
        meta = data.pop("metadata")
        data.pop("status", None)
        data.pop("minion_count", None)

        log.info("Importing tgt %s: %s", tgt_uuid, data)

        client.api.tgt.save_target_group(
            tgt_uuid=tgt_uuid, wait_for_match=wait_for_match, **data
        )
        log.info(
            "Updating tgt %s access data: %s",
            tgt_uuid,
            meta["auth"]["access"],
        )
        client.api.tgt.save_target_group_access(
            tgt_uuid=tgt_uuid, access_payload=meta["auth"]["access"]
        )

    def delete_one(self, client, tgt_uuid, data):
        log.info(
            "Deleting tgt %s: %s", tgt_uuid, data.get("name", "Unknown target name")
        )
        client.api.tgt.delete_target_group(tgt_uuid=tgt_uuid)


class JobHandler(BaseHandler):
    priority = 40

    def export(self, client, query_args):
        results = []
        ret = client.api.job.get_jobs(**query_args).ret
        for entry in ret["results"]:
            job_uuid = entry.pop("uuid")
            entry.pop("tgt_name")
            results.append(("job:{}".format(job_uuid), json.dumps(entry)))
        return results

    def exists(self, client, job_uuid):
        ret = client.api.job.get_jobs(job_uuid=job_uuid).ret
        return ret["results"] != []

    def import_one(self, client, job_uuid, data):
        meta = data.pop("metadata")
        log.info("Importing job %s: %s", job_uuid, data)
        client.api.job.save_job(job_uuid=job_uuid, **data)
        log.info(
            "Updating job %s access data: %s",
            job_uuid,
            meta["auth"]["access"],
        )
        client.api.job.save_job_access(
            job_uuid=job_uuid, access_payload=meta["auth"]["access"]
        )

    def delete_one(self, client, job_uuid, data):
        log.info("Deleting job %s: %s", job_uuid, data.get("name", "Unknown job name"))
        client.api.job.delete_job(job_uuid=job_uuid)


class CmdHandler(BaseHandler):
    def export(self, client, query_args):
        results = []
        ret = client.api.cmd.get_cmds(**query_args).ret
        for entry in ret["results"]:
            jid = entry["jid"]
            results.append(("cmd:{}".format(jid), json.dumps(entry)))
        return results


class RetHandler(BaseHandler):
    def export(self, client, query_args):
        results = []
        ret = client.api.ret.get_returns(**query_args).ret
        for entry in ret["results"]:
            jid = entry["jid"]
            results.append(("ret:{}".format(jid), json.dumps(entry)))
        return results


class PillarHandler(BaseHandler):
    priority = 20

    def export(self, client, query_args):
        results = []
        ret = client.api.pillar.get_pillars(**query_args).ret
        for entry in ret["results"]:
            pillar_uuid = entry.pop("uuid")
            results.append(("pillar:{}".format(pillar_uuid), json.dumps(entry)))
        return results

    def exists(self, client, pillar_uuid):
        ret = client.api.pillar.get_pillars(pillar_uuid=pillar_uuid).ret
        return ret["results"] != []

    def import_one(self, client, pillar_uuid, data):
        meta = data.pop("metadata")
        log.info("Importing pillar %s: %s", pillar_uuid, data)
        client.api.pillar.save_pillar(pillar_uuid=pillar_uuid, **data)
        log.info(
            "Updating pillar %s access data: %s",
            pillar_uuid,
            meta["auth"]["access"],
        )
        client.api.pillar.save_pillar_access(
            pillar_uuid=pillar_uuid, access_payload=meta["auth"]["access"]
        )

    def delete_one(self, client, pillar_uuid, data):
        log.info(
            "Deleting pillar %s: %s",
            pillar_uuid,
            data.get("name", "Unknown pillar name"),
        )
        client.api.pillar.delete_pillar(pillar_uuid=pillar_uuid)


class FsHandler(BaseHandler):
    paginated = False

    def export(self, client, query_args):
        results = []
        for saltenv in client.api.fs.get_envs().ret:
            for entry in client.api.fs.get_env(saltenv=saltenv).ret:
                fileinfo = client.api.fs.get_file(file_uuid=entry["uuid"]).ret
                file_uuid = fileinfo.pop("uuid")
                if fileinfo["content_type"] == "application/octet-stream":
                    fileinfo["contents"] = base64.b64encode(
                        fileinfo["contents"]
                    ).decode("utf-8")
                results.append(("fs:{}".format(file_uuid), json.dumps(fileinfo)))
        return results

    def exists(self, client, file_id):
        if isinstance(file_id, str):
            return client.api.fs.file_exists(file_uuid=file_id).ret
        else:
            saltenv, path = file_id
            return client.api.fs.file_exists(saltenv=saltenv, path=path).ret

    def import_one(self, client, file_uuid, data):
        meta = data.pop("metadata")
        saltenv = data.pop("saltenv")
        path = data.pop("path")
        if data["content_type"] == "application/octet-stream":
            data["contents"] = base64.b64decode(data["contents"])
        log.info("Importing file %s: %s:%s", file_uuid, saltenv, path)
        if self.exists(client, file_uuid) or self.exists(client, (saltenv, path)):
            client.api.fs.update_file(
                file_uuid=file_uuid, saltenv=saltenv, path=path, **data
            )
        else:
            client.api.fs.save_file(
                file_uuid=file_uuid, saltenv=saltenv, path=path, **data
            )
        log.info(
            "Updating file %s access data: %s",
            file_uuid,
            meta["auth"]["access"],
        )
        client.api.fs.save_file_access(
            file_uuid=file_uuid, access_payload=meta["auth"]["access"]
        )

    def delete_one(self, client, file_uuid, data):
        meta = data.pop("metadata")
        saltenv = data.pop("saltenv")
        path = data.pop("path")
        log.info("Deleting file %s: %s:%s", file_uuid, saltenv, path)
        if self.exists(client, file_uuid):
            client.api.fs.delete_file(file_uuid=file_uuid)
        elif self.exists(client, (saltenv, path)):
            client.api.fs.delete_file(saltenv=saltenv, path=path)


class MasterFsHandler(BaseHandler):
    def export(self, client, query_args):
        results = []
        for entry in client.api.masterfs.get_masterfs(**query_args).ret["results"]:
            results.append(("masterfs:{}".format(entry["master"]), json.dumps(entry)))
        return results


class ScheduleHandler(BaseHandler):
    def export(self, client, query_args):
        results = []
        for entry in client.api.schedule.get(**query_args).ret["results"]:
            sched_uuid = entry.pop("uuid")
            entry["name"] = entry.pop("sched_name")
            if "job_uuid" not in entry:
                entry.setdefault("arg", {})
            entry.pop("create_time")
            entry.pop("expired")
            entry.pop("last_fire_time")
            entry.pop("next_fire_time")
            entry.pop("sched_uuid")
            results.append(("schedule:{}".format(sched_uuid), json.dumps(entry)))
        return results

    def exists(self, client, sched_uuid):
        ret = client.api.schedule.get(uuid=sched_uuid).ret
        return ret["results"] != []

    def import_one(self, client, sched_uuid, data):
        log.info("Importing schedule %s: %s", sched_uuid, data)
        data.pop("tgt_name", None)
        data.pop("job_name", None)
        data.pop("job_access", None)
        data.pop("job_owner", None)
        data.pop("job_tgt_uuid", None)
        data.pop("job_tgt_name", None)
        client.api.schedule.save(uuid=sched_uuid, **data)

    def delete_one(self, client, sched_uuid, data):
        log.info(
            "Deleting schedule %s: %s",
            sched_uuid,
            data.get("name", "Unknown schedule name"),
        )
        client.api.schedule.remove(uuid=sched_uuid)


class UserHandler(BaseHandler):
    paginated = False
    priority = 12

    def export(self, client, query_args):
        skip_uuids = [
            acct["uuid"] for acct in client.api_constants["accounts"].values()
        ]
        results = []
        ret = client.api.auth.get_all_users(
            config_name="internal",
            include_roles=True,
            include_groups=True,
            include_custom_data=True,
        ).ret
        for entry in ret:
            account_uuid = entry.pop("uuid")
            if account_uuid in skip_uuids:
                continue
            if not entry["custom_data"]:
                entry.pop("custom_data")
            results.append(("user:{}".format(account_uuid), json.dumps(entry)))
        return results


class GroupHandler(BaseHandler):
    paginated = False
    priority = 11

    def export(self, client, query_args):
        results = []
        ret = client.api.auth.get_all_groups(
            config_name="internal", include_roles=True, include_custom_data=True
        ).ret
        for entry in ret:
            group_uuid = entry.pop("uuid")
            entry["group_name"] = entry.pop("name")
            entry["description"] = entry.pop("desc")
            if not entry["roles"]:
                entry.pop("roles")
            if not entry["custom_data"]:
                entry.pop("custom_data")
            results.append(("group:{}".format(group_uuid), json.dumps(entry)))
        return results

    def exists(self, client, group_uuid):
        try:
            client.api.auth.get_group(group_uuid=group_uuid)
            return True
        except sseapiclient.exc.RPCError:
            return False

    def import_one(self, client, group_uuid, data):
        log.info("Importing group %s: %s", group_uuid, data)
        client.api.auth.save_group(group_uuid=group_uuid, **data)

    def delete_one(self, client, group_uuid, data):
        log.info(
            "Deleting group %s: %s", group_uuid, data.get("name", "Unknown group name")
        )
        client.api.auth.delete_group(group_uuid=group_uuid)


class RoleHandler(BaseHandler):
    paginated = False
    priority = 10

    def export(self, client, query_args):
        skip_uuids = [role["uuid"] for role in client.api_constants["roles"].values()]
        results = []
        if "role_name" in query_args or "role_uuid" in query_args:
            roles = client.api.auth.get_role(**query_args).ret
        else:
            roles = client.api.auth.get_all_roles().ret
        for role_name in roles:
            role = roles[role_name]
            role_uuid = role.pop("uuid")
            if role_uuid in skip_uuids:
                continue
            role["role_name"] = role.pop("name")
            role["description"] = role.pop("desc")
            if not role["perms"]:
                role["perms"] = None
            results.append(("role:{}".format(role_uuid), json.dumps(roles[role_name])))
        return results

    def exists(self, client, role_uuid):
        try:
            client.api.auth.get_role(role_uuid)
            return True
        except sseapiclient.exc.RPCError:
            return False

    def import_one(self, client, role_uuid, data):
        log.info("Importing role %s: %s", role_uuid, data)
        client.api.auth.save_role(role_uuid=role_uuid, **data)

    def delete_one(self, client, role_uuid, data):
        log.info(
            "Deleting role %s: %s",
            role_uuid,
            data.get("role_name", "Unknown role name"),
        )
        client.api.auth.delete_role(role_uuid=role_uuid)


class App:
    def __init__(self):
        self.resource_handlers = {
            "master": MasterHandler(),
            "minion": MinionHandler(),
            "tgt": TgtHandler(),
            "job": JobHandler(),
            "cmd": CmdHandler(),
            "ret": RetHandler(),
            "pillar": PillarHandler(),
            "fs": FsHandler(),
            "masterfs": MasterFsHandler(),
            "schedule": ScheduleHandler(),
            "user": UserHandler(),
            "group": GroupHandler(),
            "role": RoleHandler(),
        }

    def parse_args(self):
        """
        Parse command line args and return the result
        """

        args = (
            (
                "mode",
                {
                    "metavar": "MODE",
                    "default": "export",
                    "choices": ("export", "import"),
                    "help": "mode of operation (%(choices)s) (default %(default)s)",
                },
            ),
            (
                "--raas",
                {
                    "metavar": "URL",
                    "default": "http://localhost:8080",
                    "help": "URL of raas service (default %(default)s)",
                },
            ),
            (
                "--auth",
                {
                    "metavar": "USER:PASS",
                    "default": None,
                    "help": "raas username and password (default %(default)s)",
                },
            ),
            (
                "--csp-url",
                {
                    "metavar": "CSP_URL",
                    "default": "https://console.cloud.vmware.com",
                    "help": "CSP Endpoint",
                },
            ),
            (
                "--csp-api-token",
                {
                    "metavar": "CSP_API_TOKEN",
                    "default": None,
                    "help": "CSP API Token (see docs)",
                },
            ),
            (
                "--csp-client-id",
                {
                    "metavar": "CSP_CLIENT_ID",
                    "default": None,
                    "help": "CSP Client ID for the corresponding OAuth2 Application (see docs)",
                },
            ),
            (
                "--csp-client-secret",
                {
                    "metavar": "CSP_CLIENT_SECRET",
                    "default": None,
                    "help": "CSP Client Secret for the corresponding OAuth2 Application (see docs)",
                },
            ),
            (
                "--csp-org-id",
                {
                    "metavar": "CSP_ORG_ID",
                    "default": None,
                    "help": "CSP Organization ID for your organization",
                },
            ),
            (
                "--insecure",
                {
                    "action": "store_true",
                    "default": False,
                    "help": "disable ssl cert verification",
                },
            ),
            (
                "--restype",
                {
                    "metavar": "RESTYPE",
                    "default": "all",
                    "choices": list(self.resource_handlers) + ["all"],
                    "nargs": "+",
                    "help": "resource types to import or export (default %(default)s)",
                },
            ),
            (
                "--query",
                {
                    "metavar": "QUERY",
                    "nargs": "+",
                    "help": "queries to filter export results, e.g.: job:name='prod',cmd='runner'",
                },
            ),
            (
                "--conflict",
                {
                    "metavar": "ACTION",
                    "default": "ignore",
                    "choices": ("ignore", "replace", "fail"),
                    "help": "how to handle resource conflicts during import (%(choices)s)\n(default %(default)s)",
                },
            ),
            (
                "--wait-for-match",
                {
                    "default": "yes",
                    "choices": ("yes", "no"),
                    "help": "Yes causes raas-dump to call save_target_group synchronously and wait for the group to be created before continuing.  Helps decrease load on RaaS.",
                },
            ),
            (
                "--quiet",
                {
                    "action": "store_true",
                    "default": False,
                    "help": "True suppresses informative output during export/import.",
                },
            ),
            (
                "--log-level",
                {
                    "metavar": "LEVEL",
                    "default": "info",
                    "choices": [
                        logging.getLevelName(n).lower() for n in range(0, 51, 10)
                    ],
                    "help": "set log level (%(choices)s) (default %(default)s)",
                },
            ),
        )

        export_only = [
            restype
            for restype in self.resource_handlers
            if not hasattr(self.resource_handlers[restype], "import_one")
        ]
        epilog = """
Options for RESTYPE: {restypes}

NOTE: the following resource types are export-only: {export_only}

WARNING: exporting some resources may expose sensitive data
""".format(
            restypes=", ".join(list(self.resource_handlers) + ["all"]),
            export_only=", ".join(export_only),
        )

        parser = argparse.ArgumentParser(
            description="Export or import raas resources",
            epilog=epilog,
            formatter_class=lambda prog: argparse.RawTextHelpFormatter(
                prog, max_help_position=40
            ),
        )

        for name, opts in args:
            parser.add_argument(name, **opts)

        return parser.parse_args()

    def query_to_kwargs(self, restype, queries):
        """
        Convert a cmdline query to kwargs that can be passed to the SSE API
        """
        kwargs = {}
        prefix = restype + ":"
        for query in queries or []:
            if query.startswith(prefix):
                for part in query.split(","):
                    try:
                        var, val = part.split("=")
                    except ValueError:
                        pass
                    kwargs["var"] = val
        return kwargs

    def export_resources(self, client):
        """
        Export resources
        """
        # The partial ordering defined by the resource priority is necessary to
        # handle possible dependencies between resources when the data is
        # re-imported. For example, a job can refer to a target group, a target
        # group can refer to a pillar, etc, and permissions data on any RBAC
        # resource can refer to a role.

        for restype in sorted(
            self.resource_handlers, key=lambda k: self.resource_handlers[k].priority
        ):
            if restype in self.config.restype or "all" in self.config.restype:
                log.info("Exporting %s data", restype)
                handler = self.resource_handlers[restype]
                query_args = self.query_to_kwargs(restype, self.config.query)
                all_pages = "page" not in query_args
                if handler.paginated:
                    query_args["page"] = int(query_args.get("page", 0))
                while True:
                    results = handler.export(client, query_args)
                    for header, data in results or []:
                        sys.stdout.write(header + " " + data + "\n")
                    if handler.paginated and results:
                        query_args["page"] += 1
                    else:
                        break

    def import_resources(self, client):
        resource_list = sys.stdin.readlines()

        if self.config.conflict == "replace":
            reverse_list = copy.copy(resource_list)
            reverse_list.reverse()
            for line in reverse_list:
                header, data = line.split(" ", maxsplit=1)
                restype, resid = header.split(":", maxsplit=1)
                if restype in self.config.restype or "all" in self.config.restype:
                    handler = self.resource_handlers[restype]
                    if not hasattr(handler, "delete_one"):
                        if restype in self.config.restype:
                            log.warning("No method to delete '%s' resource", restype)
                        continue
                    data = json.loads(data)
                    exists = handler.exists(client, resid)
                    if not exists and isinstance(handler, FsHandler):
                        exists = handler.exists(client, (data["saltenv"], data["path"]))
                    if exists:
                        handler.delete_one(client, resid, data)

        for line in resource_list:
            header, data = line.split(" ", maxsplit=1)
            restype, resid = header.split(":", maxsplit=1)
            if restype in self.config.restype or "all" in self.config.restype:
                handler = self.resource_handlers[restype]
                if not hasattr(handler, "import_one"):
                    if restype in self.config.restype:
                        log.warning("No method to import '%s' resource", restype)
                    continue
                data = json.loads(data)
                exists = handler.exists(client, resid)
                if not exists and isinstance(handler, FsHandler):
                    exists = handler.exists(client, (data["saltenv"], data["path"]))
                if exists:
                    if self.config.conflict == "ignore":
                        log.info(
                            "Ignoring conflicting %s %s",
                            restype,
                            resid,
                        )
                        continue
                    elif self.config.conflict == "fail":
                        msg = "Cannot import existing {} {}".format(restype, resid)
                        log.info("error: %s", msg)
                        raise ValueError(msg)
                if restype == "tgt":
                    handler.import_one(
                        client, self.config.wait_for_match == "yes", resid, data
                    )
                else:
                    handler.import_one(client, resid, data)

    def create_client_kwargs(self):
        kwargs = {}

        if hasattr(self.config, "raas"):
            kwargs["server"] = self.config.raas
        # if auth is passed on the CLI we don't want to try CSP, so leave the
        # CSP variables out of the kwargs we will pass to the client constructor.
        if hasattr(self.config, "auth") and self.config.auth:
            userpass = self.config.auth.split(":")
            kwargs["username"] = userpass[0]
            kwargs["password"] = userpass[1]
            if hasattr(self.config, "config_name"):
                kwargs["config_name"] = self.config.config_name
        else:
            if hasattr(self.config, "csp_api_token") and self.config.csp_api_token:
                kwargs["csp_api_token"] = self.config.csp_api_token
            if hasattr(self.config, "csp_url") and self.config.csp_url:
                kwargs["csp_url"] = self.config.csp_url
            if hasattr(self.config, "csp_client_id") and self.config.csp_client_id:
                kwargs["csp_client_id"] = self.config.csp_client_id
            if (
                hasattr(self.config, "csp_client_secret")
                and self.config.csp_client_secret
            ):
                kwargs["csp_client_secret"] = self.config.csp_client_secret
            if hasattr(self.config, "csp_org_id") and self.config.csp_org_id:
                kwargs["csp_org_id"] = self.config.csp_org_id
        if hasattr(self.config, "insecure"):
            kwargs["ssl_validate_cert"] = self.config.insecure
        return kwargs

    def run(self):
        self.config = self.parse_args()
        if self.config.quiet:
            logging.basicConfig(level=100)
        else:
            logging.basicConfig(level=self.config.log_level.upper())
        kwargs = self.create_client_kwargs()
        client = sseapiclient.APIClient(**kwargs)
        if self.config.mode == "export":
            self.export_resources(client)
        elif self.config.mode == "import":
            self.import_resources(client)


def main():
    App().run()


if __name__ == "__main__":
    main()
