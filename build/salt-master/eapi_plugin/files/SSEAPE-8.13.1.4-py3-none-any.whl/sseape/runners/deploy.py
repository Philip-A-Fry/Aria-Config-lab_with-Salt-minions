# coding: utf-8
"""
Deploy Salt Minion a target system
"""

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/


# Import Python libs
from __future__ import absolute_import
import os
import logging
import shutil
import tarfile
import uuid
import time
import random

# Import Salt libs
import salt.exceptions
import salt.utils.cloud
import salt.utils.yaml
import salt.utils.files
import salt.version
import salt.cloud

try:
    import salt.utils.smb

    HAS_SMB = True
except ImportError:
    HAS_SMB = False

try:
    import pypsexec  # pylint: disable=unused-import

    HAS_PSEXEC = True
except ImportError:
    HAS_PSEXEC = False

# Import 3rd-party libs
from sseapiclient.exc import NotConnectable, RPCError

# Import SSEAPE libs
from sseape.utils.client import make_api_client, get_pillar

log = logging.getLogger(__name__)

SSC_DEPLOY_MINION_PATH = "ssc_deploy_minion"

OS_ALLOWED = ["linux", "windows"]

REMOTE_INSTALL_DIR = "/opt/saltstack"


def _get_pillar(minion_id):
    """
    Get pillar from SSC
    """
    ret = {}
    try:
        pillar = get_pillar(opts=__opts__, runners=__salt__)
        client = make_api_client(opts=__opts__, pillar=pillar)
        name = "{master_id}-{minion_id}-pillar".format(
            master_id=__opts__.get("sseapi_cluster_id") or __opts__["id"],
            minion_id=minion_id,
        )
        pillars = client.api.pillar.get_pillars(name=name).ret
        for p in pillars["results"] or []:
            if p["pillar_type"] == "minion_deployment":
                log.debug("Read minion_deployment pillar.")
                ret = p
        if not ret:
            log.debug("No pillar - %s of type minion_deployment found.", name)
            raise salt.exceptions.SaltException(
                "No pillar - {} of type minion_deployment found".format(name)
            )
    except RPCError as exc:
        msg = "Request failed: {0}".format(exc)
        log.error(msg)
        raise salt.exceptions.SaltException(msg)
    except NotConnectable as exc:
        msg = "Request failed: {}".format(exc.message)
        log.error(msg)
        raise salt.exceptions.SaltException(msg)
    return ret


def _ensure_cloud_profile_dir():
    cloud_profile_dir = os.path.join(__opts__["config_dir"], "cloud.profiles.d")
    os.makedirs(name=cloud_profile_dir, mode=0o700, exist_ok=True)
    return cloud_profile_dir


def _ensure_cloud_provider_dir():
    cloud_provider_dir = os.path.join(__opts__["config_dir"], "cloud.providers.d")
    os.makedirs(name=cloud_provider_dir, mode=0o700, exist_ok=True)
    return cloud_provider_dir


def _ensure_cloud_deploy_dir():
    cloud_deploy_dir = os.path.join(__opts__["config_dir"], "cloud.deploy.d")
    os.makedirs(name=cloud_deploy_dir, mode=0o744, exist_ok=True)
    return cloud_deploy_dir


def _ensure_cloud_temp_dir():
    cloud_temp_dir = os.path.join(
        __opts__["config_dir"], "cloud.deploy.d", ".salt-{}".format(uuid.uuid4())
    )
    os.makedirs(name=cloud_temp_dir, mode=0o700, exist_ok=True)
    return cloud_temp_dir


def _cleanup_cloud_temp_dir(path):
    shutil.rmtree(path=path)


def _get_os_release(os_, profile_name):
    os_name, os_version, codename = None, None, None
    if os_ == "windows":
        os_name = "windows"
    elif os_ == "linux":
        os_name, os_version, codename = __salt__["deployutil.get_os_release"](
            profile=profile_name
        )
    log.debug(
        "os_name - %s, os_version - %s, codename - %s", os_name, os_version, codename
    )
    return os_name, os_version, codename


def _get_repo_meta(salt_pkg_ver, salt_pkg_os, remote_os_codename):
    redhat = """
[salt-minion-repo]
name=Salt repo for RHEL/CentOS PY3
baseurl=file://{remote_install_dir}/{salt_pkg_ver}
skip_if_unavailable=True
enabled=1
enabled_metadata=1
gpgcheck=1
gpgkey=file://{remote_install_dir}/{salt_pkg_ver}/SALTSTACK-GPG-KEY.pub""".format(
        remote_install_dir=REMOTE_INSTALL_DIR, salt_pkg_ver=salt_pkg_ver
    )

    amazon = """
[salt-minion-repo]
name=Salt repo for Amazon Linux 2 PY3
baseurl=file://{remote_install_dir}/{salt_pkg_ver}
skip_if_unavailable=True
priority=10
enabled=1
enabled_metadata=1
gpgcheck=1
gpgkey=file://{remote_install_dir}/{salt_pkg_ver}/SALTSTACK-GPG-KEY.pub""".format(
        remote_install_dir=REMOTE_INSTALL_DIR, salt_pkg_ver=salt_pkg_ver
    )

    ubuntu = """
deb [signed-by={remote_install_dir}/{salt_pkg_ver}/salt-archive-keyring.gpg] file://{remote_install_dir}/{salt_pkg_ver} {codename} main
    """.format(
        remote_install_dir=REMOTE_INSTALL_DIR,
        salt_pkg_ver=salt_pkg_ver,
        codename=remote_os_codename,
    )

    debian = """
deb [signed-by={remote_install_dir}/{salt_pkg_ver}/salt-archive-keyring.gpg] file://{remote_install_dir}/{salt_pkg_ver} {codename} main
        """.format(
        remote_install_dir=REMOTE_INSTALL_DIR,
        salt_pkg_ver=salt_pkg_ver,
        codename=remote_os_codename,
    )

    pkg_os_map = {
        "redhat": {
            "repo_data": redhat,
            "repo_fname": "/etc/yum.repos.d/salt.repo",
        },
        "amazon": {"repo_data": amazon, "repo_fname": "/etc/yum.repos.d/salt.repo"},
        "ubuntu": {
            "repo_data": ubuntu,
            "repo_fname": "/etc/apt/sources.list.d/salt.list",
        },
        "debian": {
            "repo_data": debian,
            "repo_fname": "/etc/apt/sources.list.d/salt.list",
        },
    }

    log.debug("Returning pkg_os_map for salt_pkg_os - %s", salt_pkg_os)
    return pkg_os_map.get(salt_pkg_os, {})


def _create_repo_file(salt_pkg_ver, salt_pkg_os, remote_os_codename, temp_dir):
    repo_meta = _get_repo_meta(
        salt_pkg_ver=salt_pkg_ver,
        salt_pkg_os=salt_pkg_os,
        remote_os_codename=remote_os_codename,
    )
    repo_file_name = os.path.join(temp_dir, os.path.basename(repo_meta["repo_fname"]))
    repo_meta["repo_local_fname"] = repo_file_name
    with salt.utils.files.fopen(repo_file_name, "w") as fp:
        fp.write(repo_meta["repo_data"])
    log.debug("Repo file written with meta - %s", repo_meta)
    return repo_meta


def _get_salt_master_version_info():
    log.debug(
        "Salt master version info - %s, version - %s",
        salt.version.__version_info__,
        salt.version.__version__,
    )
    return salt.version.__version_info__, salt.version.__version__


def _get_salt_pkg(remote_os_name, deploy_dir, remote_os_version=None):
    log.debug(
        "Getting salt package for remote_os_name - %s, remote_os_version - %s, deploy_dir - %s",
        remote_os_name,
        remote_os_version,
        deploy_dir,
    )
    # When package name contains redhat, the remote os can be one of centos, redhat.
    # The values in the list are ID as found in /etc/os-release on the remote host
    pkg_os_code_map = {
        "redhat": ["centos", "rhel", "ol", "almalinux"],
        "amazon": ["amzn"],
        "debian": ["debian"],
        "ubuntu": ["ubuntu"],
        "windows": ["windows"],
    }

    # Salt 3002 is the minimum version we want to support with this feature. If the salt master is running a lower
    # version, default to 3003
    salt_version_map = {
        "2019": "3003",
        "3000": "3003",
        "3001": "3003",
        "3002": "3003",
    }

    # Support only amd64 for both debian and windows for this release. Querying the remote host for arch isn't
    # implemented yet. Salt pkgs for other OS's are built for install on only one arch
    salt_arch_map = {
        "debian": "amd64",
        "windows": "AMD64",
    }

    # For redhat, the major version works for the minor versions (found as soft links on repo.saltproject.io)
    if remote_os_name in ["rhel", "ol", "almalinux"]:
        remote_os_version = remote_os_version.split(".")[0]

    salt_master_version_info, salt_master_version = _get_salt_master_version_info()
    salt_pkg_name, salt_pkg_ver, salt_pkg_os = None, None, None
    for root, dirs, files in os.walk(deploy_dir):
        for f in files:
            if f.startswith("salt") and f.endswith("tar.gz"):
                pkg_ver, pkg_os, pkg_os_ver, pkg_arch = (
                    f.lstrip("salt-").rstrip(".tar.gz").split("-")
                )
                log.debug(
                    "Matching pkg_ver - %s, pkg_os - %s, pkg_os_ver - %s, pkg_arch - %s",
                    pkg_ver,
                    pkg_os,
                    pkg_os_ver,
                    pkg_arch,
                )
                if pkg_ver.split(".")[0] == salt_version_map.get(
                    str(salt_master_version_info[0]), str(salt_master_version_info[0])
                ):
                    for relname in pkg_os_code_map.get(pkg_os, []):
                        if pkg_os == remote_os_name == "windows":
                            if pkg_arch == salt_arch_map[pkg_os]:
                                (
                                    salt_pkg_name,
                                    salt_pkg_ver,
                                    salt_pkg_os,
                                    salt_pkg_arch,
                                ) = (f, pkg_ver, pkg_os, pkg_arch)
                                return (
                                    salt_pkg_name,
                                    salt_pkg_ver,
                                    salt_pkg_os,
                                    salt_pkg_arch,
                                )
                        elif (
                            relname == remote_os_name
                            and pkg_os_ver == remote_os_version
                        ):
                            if (
                                salt_arch_map.get(pkg_os)
                                and salt_arch_map.get(pkg_os) != pkg_arch
                            ):
                                continue
                            salt_pkg_name, salt_pkg_ver, salt_pkg_os, salt_pkg_arch = (
                                f,
                                pkg_ver,
                                pkg_os,
                                pkg_arch,
                            )
                            return (
                                salt_pkg_name,
                                salt_pkg_ver,
                                salt_pkg_os,
                                salt_pkg_arch,
                            )

    # If we reach here, no matching package was found for the remote os, os version and salt master version combination
    raise salt.exceptions.SaltException(
        "No matching salt package was found for remote os - {},"
        " os version - {}, salt master version - {} combination.".format(
            remote_os_name, remote_os_version, salt_master_version
        )
    )


def _get_airgap_install_deps(os_, profile_name, deploy_dir, temp_dir):
    """
    Resolve all dependencies for air-gapped install of salt-minion.
    Dependencies:
    1. Determine the os and version of the target host
    2. Choose salt minion package to install based on os and salt master version
    3. Create repo file in temp_dir based on os_release and salt package version
    4. Create file_map to upload the dependent files to target host
    5. Create preflight_cmds to gunzip salt tarball
    6. Set script_args to not install any additional dependencies

    Returns a dictionary containing

    file_map - Map of local files to remote files
    script_args - Arguments for the installation script
    preflight_cmds - List of commands to run before installing the minion
    """
    ret = {
        "file_map": {},
        # Refer: https://github.com/saltstack/salt-bootstrap
        # -r  Disable all repository configuration performed by this script. This
        #       option assumes all necessary repository configuration is already present
        #       on the system.
        # -b  Assume that dependencies are already installed and software sources are
        #       set up. If git is selected, git tree is still checked out as dependency
        #       step.
        "script_args": " -b -r -x python3 ",
        "preflight_cmds": [],
    }

    salt_master_version_info, _ = _get_salt_master_version_info()
    # the version info is tuple of integers e.g. (3005, 3)
    version = salt_master_version_info[0]
    if version and version >= int(
        os.getenv("TIAMAT_ONEDIR_MINION_START_VERSION", "3006")
    ):
        ret["script_args"] += " onedir "

    log.debug("Getting params for airgap install.")
    remote_os_name, remote_os_version, remote_os_codename = _get_os_release(
        os_=os_, profile_name=profile_name
    )
    salt_pkg_name, salt_pkg_ver, salt_pkg_os, salt_pkg_arch = _get_salt_pkg(
        remote_os_name=remote_os_name,
        remote_os_version=remote_os_version,
        deploy_dir=deploy_dir,
    )
    repo_meta = _create_repo_file(
        salt_pkg_ver=salt_pkg_ver,
        salt_pkg_os=salt_pkg_os,
        remote_os_codename=remote_os_codename,
        temp_dir=temp_dir,
    )

    # Create file map for salt pkg and repo file
    ret["file_map"][os.path.join(deploy_dir, salt_pkg_name)] = os.path.join(
        REMOTE_INSTALL_DIR, salt_pkg_name
    )
    ret["file_map"][repo_meta["repo_local_fname"]] = repo_meta["repo_fname"]

    # Create pre-flight command to extract salt pkg
    cmd = "tar zxvf {src} -C {dest}".format(
        src=os.path.join(REMOTE_INSTALL_DIR, salt_pkg_name), dest=REMOTE_INSTALL_DIR
    )
    ret["preflight_cmds"].append(cmd)

    # For ubuntu and debian, run apt-get update to recognize new local (salt) packages
    # redhat based systems recognize local (salt) packages automatically.
    if remote_os_name in ("ubuntu", "debian"):
        cmd = "apt-get update"
        ret["preflight_cmds"].append(cmd)

    log.debug("Returning install params.")

    return ret


def _init_cloud_dirs():
    cloud_profile_dir = _ensure_cloud_profile_dir()
    cloud_provider_dir = _ensure_cloud_provider_dir()
    cloud_deploy_dir = _ensure_cloud_deploy_dir()
    cloud_temp_dir = _ensure_cloud_temp_dir()
    return cloud_provider_dir, cloud_profile_dir, cloud_deploy_dir, cloud_temp_dir


def _write_cloud_config(file_name, data):
    with os.fdopen(
        os.open(file_name, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o700), "w"
    ) as fp:
        fp.write(data)


def _write_cloud_provider_config(minion_id, provider_dir):
    provider_config = {}
    pillar = _get_pillar(minion_id)
    additional_auth_params = pillar["pillar"]["additional_auth_params"]
    provider_name = "ssc_saltify_provider"
    provider_config[provider_name] = dict(driver="saltify")

    # When custom provider configs are specified for provider, write the provider configs in the minion namespace
    if isinstance(additional_auth_params, dict) and isinstance(
        additional_auth_params.get("provider"), dict
    ):
        provider_config = {}
        provider_name = "ssc_{minion_id}_provider".format(minion_id=minion_id)
        provider_config.setdefault(provider_name, additional_auth_params["provider"])

    file_name = os.path.join(provider_dir, provider_name + ".conf")
    # handle concurrent requests. don't truncate and write provider file, if it already exists.
    if not os.path.exists(file_name):
        _write_cloud_config(
            file_name=os.path.join(provider_dir, provider_name + ".conf"),
            data=salt.utils.yaml.safe_dump(provider_config, default_flow_style=False),
        )
    return provider_name


def _get_win_installer(os_, deploy_dir, temp_dir):
    salt_pkg_name, salt_pkg_ver, salt_pkg_os, salt_pkg_arch = _get_salt_pkg(
        remote_os_name=os_, deploy_dir=deploy_dir
    )

    win_installer = os.path.join(
        temp_dir, "Salt-Minion-{}-Py3-{}-Setup.exe".format(salt_pkg_ver, salt_pkg_arch)
    )
    with tarfile.open(os.path.join(deploy_dir, salt_pkg_name), "r:gz") as tf:
        tf.extractall(path=temp_dir)
        if os.path.isfile(win_installer):
            return win_installer
    raise salt.exceptions.SaltException(
        "Unable to locate installer Salt-Minion-{}-Py3-{}-Setup.exe".format(
            salt_pkg_ver, salt_pkg_arch
        )
    )


def _write_cloud_profile_config(
    provider_name,
    profile_dir,
    temp_dir,
    minion_id,
    os_=None,
    deploy_dir=None,
    deploy=None,
    additional_minion_params=None,
    airgap_install_params=None,
):
    profile_config = {}
    pillar = _get_pillar(minion_id)
    additional_auth_params = pillar["pillar"]["additional_auth_params"]
    master = pillar["pillar"]["master_address"]
    profile_name = "ssc_{minion_id}_profile".format(minion_id=minion_id)
    profile_config[profile_name] = dict(
        provider=provider_name, minion=dict(master=master)
    )
    if pillar["pillar"].get("host_name_ip"):
        profile_config[profile_name]["ssh_host"] = pillar["pillar"]["host_name_ip"]
    if pillar["pillar"].get("username"):
        if os_ == "windows":
            profile_config[profile_name]["win_username"] = pillar["pillar"]["username"]
        else:
            profile_config[profile_name]["ssh_username"] = pillar["pillar"]["username"]

    # Use password, private_key_path or private_key (string) to authenticate with the target host
    if pillar["pillar"].get("private_key_path"):
        profile_config[profile_name]["key_filename"] = pillar["pillar"][
            "private_key_path"
        ]
    elif pillar["pillar"].get("private_key"):
        # Write the private key (mode 0o400) to temp dir, cleaned up after install
        key_filename = os.path.join(temp_dir, "key-{}".format(profile_name))
        _write_cloud_config(
            file_name=key_filename, data=pillar["pillar"]["private_key"]
        )
        profile_config[profile_name]["key_filename"] = key_filename
    elif pillar["pillar"].get("password"):
        if os_ == "windows":
            profile_config[profile_name]["win_password"] = pillar["pillar"]["password"]
        else:
            profile_config[profile_name]["password"] = pillar["pillar"]["password"]

    # Get windows installer filename
    if os_ == "windows":
        profile_config[profile_name]["win_installer"] = _get_win_installer(
            os_=os_, deploy_dir=deploy_dir, temp_dir=temp_dir
        )

    # Update file_map, script and script_args for airgap install
    if airgap_install_params:
        profile_config[profile_name]["file_map"] = airgap_install_params["file_map"]
        profile_config[profile_name]["script_args"] = airgap_install_params[
            "script_args"
        ]
        profile_config[profile_name]["preflight_cmds"] = airgap_install_params[
            "preflight_cmds"
        ]
    else:
        salt_master_version_info, salt_master_version = _get_salt_master_version_info()
        if "." not in salt_master_version:
            salt_master_version = salt_master_version + ".0"

        # the version info is tuple of integers e.g. (3005, 3)
        version = salt_master_version_info[0]

        if version and version >= int(
            os.getenv("TIAMAT_ONEDIR_MINION_START_VERSION", "3006")
        ):
            # Tiamat onedir salt minion installation (starting v3006 onwards)
            # It can be validated in transition phase using this env var
            profile_config[profile_name][
                "script_args"
            ] = " -x python3 onedir {} ".format(salt_master_version)
        else:
            # 3005 has both (tiamat onedir and classic), We are going to use classic for 3005 as default
            profile_config[profile_name][
                "script_args"
            ] = " -x python3 stable {} ".format(salt_master_version)

    # Don't generate minion public keys and pre-accept them on the master.
    # There is a bug in salt-cloud due to which minion keys end up in multiple states (accepted, denied, unaccepted)
    # on the master and hence making the newly installed minion unusable.
    # RaaS will initiate the key acceptance flow due to this change, which should take care of scenarios when
    # auto_accept = True or False.
    profile_config[profile_name]["pub_key"] = ""
    profile_config[profile_name]["priv_key"] = ""
    setattr(salt.utils.cloud, "accept_key", lambda *args, **kwargs: True)

    # Override map_providers_parallel with map_providers. Both provide the same functionality,
    # but map_providers_parallel hangs indefinitely for concurrent requests. Delay mitigates it to some extent only.
    setattr(salt.cloud.Cloud, "map_providers_parallel", salt.cloud.Cloud.map_providers)

    # set deploy, passing it in as a param to cloud.profile results in some stale value of deploy picked up from
    # __opts__ in case of concurrent requests.
    if deploy:
        profile_config[profile_name]["deploy"] = True
    else:
        profile_config[profile_name]["deploy"] = False

    # Update additional profile configs
    # Enable users to override even airgap install params
    if isinstance(additional_auth_params, dict) and isinstance(
        additional_auth_params.get("profile"), dict
    ):
        profile_config[profile_name].update(additional_auth_params["profile"])

    # Update minion configs
    if isinstance(additional_minion_params, dict):
        profile_config[profile_name]["minion"].update(additional_minion_params)

    _write_cloud_config(
        file_name=os.path.join(profile_dir, profile_name + ".conf"),
        data=salt.utils.yaml.safe_dump(profile_config, default_flow_style=False),
    )
    return profile_name


def _validate_libs(os_):
    """
    Validate if requisite libraries are installed
    """
    if os_ == "windows":
        missing = []
        if not HAS_SMB:
            missing.append("smbprotocol")
        if not HAS_PSEXEC:
            missing.append("pypsexec")
        if missing:
            raise salt.exceptions.SaltException(
                "Please install {} libraries on the salt-master".format(
                    ", ".join(missing)
                )
            )


def _validate_input(os_, additional_minion_params, airgap_install, installer_file_name):
    if os_ not in OS_ALLOWED:
        raise salt.exceptions.SaltException("{} not in list of allowed OS".format(os_))
    if additional_minion_params and not isinstance(additional_minion_params, dict):
        raise salt.exceptions.SaltException("additional_minion_params should be a dict")
    if airgap_install and not isinstance(airgap_install, bool):
        raise salt.exceptions.SaltException("airgap_install should be boolean")
    if installer_file_name and not os.path.exists(installer_file_name):
        raise salt.exceptions.SaltException(
            "{} not found on master".format(installer_file_name)
        )


def delay(os_):
    """
    # Wait a minute! (Literally!)
    # Though map_providers_parallel fn in salt/cloud/__init__.py uses multiprocessing.Pool and Queue, it doesn't handle
    # concurrent requests well and as a result, some of them hang indefinitely.
    # 1 minute may seem high for non-current requests, but it is the only way to randomize and get around this bug.
    """
    secs = random.random() * 60
    log.info("Waiting for %s seconds", secs)
    time.sleep(secs)

    # The below delays are necessary because vRA is sending in requests before the hosts are fully ready.
    # Can be removed once salt or vRA does the real fix.
    # For windows, add extra delay for the host to be ready.
    if os_ == "windows":
        log.info("Waiting for windows host to be ready.")
        # Leaving this as an un-documented parameter.
        time.sleep(__opts__.get("sseapi_win_minion_deploy_delay", 180))
    else:
        log.info("Waiting for linux host to be ready.")
        # Leaving this as an un-documented parameter.
        time.sleep(__opts__.get("sseapi_linux_minion_deploy_delay", 90))


def minion(
    minion_id,
    os="linux",
    additional_minion_params=None,
    airgap_install=False,
    installer_file_name=None,
    **kwargs
):
    """
    Deploy minion runner
    """
    ret = {}
    log.info(
        "deploy.minion:%s:Started minion deployment with inputs: minion_id - %s, os - %s, "
        "additional_minion_params - %s, airgap_install - %s, installer_file_name - %s, kwargs - %s",
        minion_id,
        minion_id,
        os,
        additional_minion_params,
        airgap_install,
        installer_file_name,
        kwargs,
    )

    _validate_input(
        os_=os,
        additional_minion_params=additional_minion_params,
        airgap_install=airgap_install,
        installer_file_name=installer_file_name,
    )
    log.info("deploy.minion:%s:Input validation complete.", minion_id)

    _validate_libs(os_=os)
    log.info("deploy.minion:%s:Library requisite validation complete.", minion_id)

    provider_dir, profile_dir, deploy_dir, temp_dir = _init_cloud_dirs()
    log.info("deploy.minion:%s:Created cloud dirs.", minion_id)

    # Write config for Saltify Provider
    provider_name = _write_cloud_provider_config(
        minion_id=minion_id, provider_dir=provider_dir
    )
    log.info("deploy.minion:%s:Written provider config - %s.", minion_id, provider_name)

    # Write config for Cloud Profile
    profile_name = _write_cloud_profile_config(
        minion_id=minion_id,
        provider_name=provider_name,
        profile_dir=profile_dir,
        temp_dir=temp_dir,
        deploy_dir=deploy_dir,
        deploy=False,
        os_=os,
        additional_minion_params=additional_minion_params,
    )
    log.info("deploy.minion:%s:Written profile config - %s.", minion_id, profile_name)

    delay(os_=os)

    # Verify if the target host is reachable
    # show_deploy_args = None needs to be passed, salt-cloud arg parser fails if not passed.
    log.info(
        "deploy.minion:%s:Verifying if remote host is accessible. Profile - %s",
        minion_id,
        profile_name,
    )
    ret = __salt__["cloud.profile"](profile_name, minion_id, show_deploy_args=None)

    log.info(
        "deploy.minion:%s:Remote host is accessible. Profile - %s",
        minion_id,
        profile_name,
    )

    # If we reached this far, the target host is accessible using provided credentials.
    # Now, see if we need to do an airgap install
    airgap_install_params = None
    if airgap_install and os != "windows":
        airgap_install_params = _get_airgap_install_deps(
            os_=os, profile_name=profile_name, deploy_dir=deploy_dir, temp_dir=temp_dir
        )
        log.info(
            "deploy.minion:%s:Airgap install params - %s",
            minion_id,
            airgap_install_params,
        )

    # Re-write profile based on airgap_install_params and deploy param
    profile_name = _write_cloud_profile_config(
        provider_name=provider_name,
        minion_id=minion_id,
        profile_dir=profile_dir,
        temp_dir=temp_dir,
        deploy_dir=deploy_dir,
        deploy=True,
        os_=os,
        additional_minion_params=additional_minion_params,
        airgap_install_params=airgap_install_params,
    )
    log.info(
        "deploy.minion:%s:Re-wrote profile - %s based on airgap_install_params and deploy param",
        minion_id,
        profile_name,
    )

    # Install new minion
    # cloud.profile runner has flaky behavior. Sometimes fails with AttributeError: 'bool' object has no attribute 'pop'
    # in salt/cloud/__init__.py\", line 1430, in run_profile\n    ret[name].pop(\"deploy_kwargs\", None)
    # Unable to replicate. Fixes - https://jira.eng.vmware.com/browse/SSC-296
    log.info(
        "deploy.minion:%s:Starting minion deployment. Profile - %s",
        minion_id,
        profile_name,
    )
    ret = __salt__["cloud.profile"](profile_name, minion_id, show_deploy_args=False)
    log.info(
        "deploy.minion:%s:Minion deployment complete. Profile - %s",
        minion_id,
        profile_name,
    )

    # Check for deployed=True in ret. If not, raise Salt exception.
    if not ret.get(minion_id, {}).get("deployed") is True:
        log.error(
            "deploy.minion:%s:Error in installing salt minion. Profile - %s",
            minion_id,
            profile_name,
        )
        raise salt.exceptions.SaltException(
            "Error in installing salt minion - {}".format(str(ret))
        )

    # Cleanup cloud temp dir
    _cleanup_cloud_temp_dir(path=temp_dir)
    log.info("deploy.minion:%s:Cleaned up temp dir.")

    return ret
