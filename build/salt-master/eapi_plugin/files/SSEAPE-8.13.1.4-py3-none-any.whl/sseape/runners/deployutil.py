# coding: utf-8
"""
Utility runner for deploying Salt Minion a target system
"""

# Import Python libs
from __future__ import absolute_import
import os
import logging
import time
import traceback

# Import 3rd-party libs

# Import Salt libs
import salt.utils.cloud
import salt.utils.vt
import salt.cloud
from salt.exceptions import (
    SaltCloudPasswordError,
    SaltCloudSystemExit,
)
from salt.utils.cloud import SSH_PASSWORD_PROMP_RE, SSH_PASSWORD_PROMP_SUDO_RE

# Import SSEAPE libs

log = logging.getLogger(__name__)

SSHSTDOUT = ""


def _get_client():
    """
    Return cloud client
    """
    client = salt.cloud.CloudClient(
        os.path.join(os.path.dirname(__opts__["conf_file"]), "cloud")
    )
    return client


# !!! ALERT !!!
# COPIED FROM salt.utils.cloud
# EXPOSES stdout using a global variable SSHSTDOUT
# REQUIRED to get os-release of the target linux system.
# Fortunately this is in a runner, so all of this hackery dies with this process.
def _exec_ssh_cmd(cmd, error_msg=None, allow_failure=False, **kwargs):
    global SSHSTDOUT
    if error_msg is None:
        error_msg = "A wrong password has been issued while establishing ssh session."
    password_retries = kwargs.get("password_retries", 3)
    try:
        stdout, stderr = None, None
        proc = salt.utils.vt.Terminal(
            cmd,
            shell=True,
            log_stdout=True,
            log_stderr=True,
            stream_stdout=kwargs.get("display_ssh_output", True),
            stream_stderr=kwargs.get("display_ssh_output", True),
        )
        sent_password = 0
        while proc.has_unread_data:
            stdout, stderr = proc.recv()
            # !!! ALERT !!!
            # grab stdout with global variable SSHSTDOUT.
            # This is the only way to do it right now, as salt-cloud modules don't return stdout anywhere else.
            if stdout:
                SSHSTDOUT += stdout
            if stdout and SSH_PASSWORD_PROMP_RE.search(stdout):
                # if authenticating with an SSH key and 'sudo' is found
                # in the password prompt
                if (
                    "key_filename" in kwargs
                    and kwargs["key_filename"]
                    and SSH_PASSWORD_PROMP_SUDO_RE.search(stdout)
                ):
                    proc.sendline(kwargs["sudo_password"])
                # elif authenticating via password and haven't exhausted our
                # password_retires
                elif kwargs.get("password", None) and (
                    sent_password < password_retries
                ):
                    sent_password += 1
                    proc.sendline(kwargs["password"])
                # else raise an error as we are not authenticating properly
                #  * not authenticating with an SSH key
                #  * not authenticating with a Password
                else:
                    raise SaltCloudPasswordError(error_msg)
            # 0.0125 is really too fast on some systems
            time.sleep(0.5)
        if proc.exitstatus != 0 and allow_failure is False:
            raise SaltCloudSystemExit(
                "Command '{}' failed. Exit code: {}".format(cmd, proc.exitstatus)
            )
        return proc.exitstatus
    except salt.utils.vt.TerminalException as err:
        trace = traceback.format_exc()
        log.error(error_msg.format(cmd, err, trace))
    finally:
        proc.close(terminate=True, kill=True)
    # Signal an error
    return 1


def _parse_os_release(data):
    os_name, version, codename = "", "", ""
    if data:
        for d in data.split("\n"):
            kv = d.split("=")
            if kv[0] == "ID" and kv[1]:
                os_name = str(kv[1]).replace('"', "").lower()
            if kv[0] == "VERSION_ID" and kv[1]:
                version = str(kv[1]).replace('"', "")
            if kv[0] == "VERSION_CODENAME" and kv[1]:
                codename = kv[1]
    return os_name, version, codename


def get_os_release(profile=None):
    """
    Get os release and version from target host using the profile name
    """
    client = _get_client()
    vm_ = client.opts["profiles"][profile]
    kwargs = {
        "hostname": vm_["ssh_host"],
        "port": vm_.get("ssh_port", 22),
        "username": vm_.get("ssh_username", "root"),
        "gateway": vm_.get("gateway", None),
        "maxtries": 3,
    }

    for k in ("password", "key_filename"):
        if vm_.get(k):
            kwargs[k] = vm_.get(k)

    setattr(salt.utils.cloud, "_exec_ssh_cmd", _exec_ssh_cmd)
    # Every systemd managed instance should have /etc/os-release.
    salt.utils.cloud.root_cmd("cat /etc/os-release", tty=False, sudo=False, **kwargs)
    return _parse_os_release(data=SSHSTDOUT)
