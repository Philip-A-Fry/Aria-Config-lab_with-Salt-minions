"""
Return cached data from minions
"""

import logging

import salt.config
import salt.loader
import salt.serializers.msgpack
from salt.exceptions import CommandExecutionError
from salt.serializers import DeserializationError

log = logging.getLogger(__name__)

__func_alias__ = {
    "list_": "list",
}


def list_(cache, key=None):
    """
    List keys stored in a local cache.

    CLI Examples:

    .. code-block:: bash

        salt-run sseapi_cache.list tgt
        salt-run sseapi_cache.list tgt 685ad850%
    """
    if key is None:
        key = "%"

    __salt__ = salt.loader.minion_mods(__opts__)

    try:
        entries = __salt__["sseapi_local_cache.get_many"](cache=cache, keypat=key)
        ret = [key for (key, _) in entries]
    except CommandExecutionError as exc:
        log.info(
            "Failed to read entries from local cache %s: %s",
            cache,
            str(exc),
        )
        ret = None
    return ret


def fetch(cache, key=None):
    """
    Fetch entries from a local cache.

    CLI Examples:

    .. code-block:: bash

        salt-run sseapi_cache.fetch tgt
        salt-run sseapi_cache.fetch tgt 685ad850%
    """
    if key is None:
        key = "%"

    __salt__ = salt.loader.minion_mods(__opts__)

    try:
        entries = __salt__["sseapi_local_cache.get_many"](cache=cache, keypat=key)
    except CommandExecutionError as exc:
        log.info(
            "Failed to read entries from local cache %s: %s",
            cache,
            str(exc),
        )
        entries = []

    ret = {}
    for key, val in entries:
        try:
            retval = salt.serializers.msgpack.deserialize(val)
        except DeserializationError:
            retval = "<encrypted>"
        ret[key] = retval
    return ret


def flush(cache, key=None):
    """
    Remove entries from a local cache. If no key is specified, flush the entire
    cache.

    CLI Examples:

    .. code-block:: bash

        salt-run sseapi_cache.flush tgt key=685ad850%
        salt-run sseapi_cache.flush tgt
    """
    if key is None:
        key = "%"

    __salt__ = salt.loader.minion_mods(__opts__)

    try:
        __salt__["sseapi_local_cache.flush"](cache=cache, keypat=key)
        ret = True
    except CommandExecutionError as exc:
        log.info(
            "Failed to flush entries from local cache %s: %s",
            cache,
            str(exc),
        )
        ret = False
    return ret


def info(cache):
    """
    Report some details about a cache.

    CLI Example:

    .. code-block:: bash

        salt-run sseapi_cache.info tgt
    """
    __salt__ = salt.loader.minion_mods(__opts__)

    try:
        ret = __salt__["sseapi_local_cache.info"](cache=cache)
    except CommandExecutionError as exc:
        log.info(
            "Failed to get info about local cache %s: %s",
            cache,
            str(exc),
        )
        ret = None
    return ret
