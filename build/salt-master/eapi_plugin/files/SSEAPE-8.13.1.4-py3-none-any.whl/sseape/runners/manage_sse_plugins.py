# coding: utf-8
"""
Salt-Master SSE Plugin Upgrade runner
"""
import logging
import sys
import os
import multiprocessing
import subprocess
import tempfile
import time

import salt.client
import salt.config

from sseape.utils.client import make_api_client, get_pillar

logger = logging.getLogger(__name__)


class MasterPluginUpgradeOrchestrator(object):
    """
    Perform upgrade config/image steps outlined in https://jira.eng.vmware.com/browse/VRAE-29100
    ...
    The upgrade orchestration should be idempotent
    """

    def __init__(self, *args, **kwargs):
        self.opts = kwargs.get("opts")
        self._raas_client = None
        self._timeout_wait_for_master_restart_in_seconds = (
            kwargs.get("timeout_wait_for_master_restart_in_seconds") or 15
        )

        self.logger = kwargs.get("logger")
        self._configure_logger_for_multiprocessing(logger=self.logger)

        if self.opts is None:
            self.opts = salt.config.master_config(
                os.path.join(salt.syspaths.CONFIG_DIR, "master")
            )

        if self._raas_client is None:
            pillar = get_pillar(opts=self.opts)
            self._raas_client = make_api_client(opts=self.opts, pillar=pillar)

    def _rollback(self):
        """
        Rollback upgrade.
        This method should be called from the spawned monitor process.
        :return:
        """
        self.logger.info("Starting rollback")
        # TODO: fill in this rollback impl.
        self._restart_master()
        self.logger.info("Rollback complete")

    def _restart_master(self):
        """
        Restart salt-master service via some form of service manager. Exception is raised in case of non-zero return code.
        This method should be called from the spawned monitor process.
        :return:
        """
        self.logger.info("Restarting salt-master")
        self._invoke_salt_call_command("service.stop", "salt-master")
        self._invoke_salt_call_command("service.start", "salt-master")
        self.logger.info("Restart of master-master complete")

    def _check_master_running_status_with_retry(self):
        """
        Get salt-master service status via some form of service manager.
        Exception is raised in case salt-master is not confirmed to be running (after a few retries).
        :return:
        """
        result = None
        sleep_between_iterations = 1
        sleep_remaining_in_seconds = (
            self._timeout_wait_for_master_restart_in_seconds or sleep_between_iterations
        )

        while not result and sleep_remaining_in_seconds > 0:
            # result has a list of PIDs
            result = self._invoke_salt_call_command("service.status", "salt-master")
            sleep_remaining_in_seconds -= sleep_between_iterations
            time.sleep(sleep_between_iterations)

        if not result:
            raise salt.exceptions.SaltException(
                "Cannot confirm salt-master service status to be up and running"
            )
        else:
            logger.info("salt-master is up and running")

    def _invoke_salt_call_command(self, fun, *args):
        """
        Runs the equivalent of "salt-call --local". A running minion is not required,
        but a minion config must be present on the system in order for ``salt.client.Caller`` to work.
        system.
        :param fun: function to run, e.g.
        :param args:
        :return:
        """
        self.logger.info(
            "Running the equivalent of [salt-call --local %s %s]", fun, *args
        )

        # Note: ``Caller`` is the same interface used by the :command:`salt-call`
        # command-line tool on the Salt Minion.
        __opts__ = salt.config.minion_config(
            os.path.join(salt.syspaths.CONFIG_DIR, "minion")
        )
        __opts__["file_client"] = "local"
        caller = salt.client.Caller(mopts=__opts__)
        result = caller.cmd(fun, *args)

        if not result:
            raise salt.exceptions.SaltException(
                f"Command [{fun} {' '.join(args)}] failed with exit code {result['retcode']}"
            )
        return result

    def _invoke_shell_command(self, command_with_args):
        """
        Raises CalledProcessError if command returns a non-zero error code
        :param command_with_args:
        :return:
        """
        self.logger.info("Running command [%s]", command_with_args)
        with tempfile.TemporaryDirectory() as tempdirname:
            process = None
            stdout = None
            stderr = None
            try:
                process = subprocess.run(
                    command_with_args,
                    cwd=tempdirname,
                    timeout=600,  # 10 minutes max
                    shell=True,
                    capture_output=True,  # this makes command output not show up in logs but allows us to capture it
                    check=True,
                )
                stdout = process.stdout
                stderr = process.stderr
            except subprocess.CalledProcessError as exc:
                stdout = exc.stdout
                stderr = exc.stderr
                raise
            finally:
                # TODO: is there a better way to capture stdout/stderr and also have this output show up in the logs?
                if stdout:
                    self.logger.debug("%s", stdout)
                if stderr:
                    self.logger.debug("%s", stderr)

        return process

    def _upgrade_plugins(self, plugin_cache_directory=None):
        """
        Install/upgrade new plugin .whl images
        :return:
        """
        plugin_cache_directory = self._get_master_plugin_cache_directory(
            plugin_cache_directory=plugin_cache_directory
        )

        num_upgraded = 0
        if os.path.isdir(plugin_cache_directory):
            for direntry in os.scandir(plugin_cache_directory):
                if direntry.name.endswith(".whl"):
                    whlpath = os.path.join(plugin_cache_directory, direntry.name)
                    self._invoke_salt_call_command("pip.install", whlpath)
                    num_upgraded += 1
            self.logger.info("Done with plugin .whl upgrades")
        else:
            self.logger.info(
                "No plugins in path [%s]. Nothing to do.", plugin_cache_directory
            )

        return num_upgraded

    def _monitor_and_finalize_upgrade(self, *args, **kwargs):
        """
        Assume that we are running as a spawned subprocess so that we can safely stop/start/restart salt-master.
        :param args:
        :param kwargs:
        :return:
        """
        success = True
        try:
            self.logger.debug("Background monitor process starting")
            self._restart_master()
            self._check_master_running_status_with_retry()
            self.logger.info("Upgrade complete")
        except Exception:  # pylint: disable=broad-except
            success = False
            self.logger.error("Upgrade failed")

        if not success:
            self._rollback()

        self._signal_upgrade_status_to_raas(success=success)

    def _signal_upgrade_status_to_raas(self, success=False):
        """
        Calls RaaS API to signal upgrade status
        TODO: replace this wih the correct API call when it is supposed by RaaS
        :return:
        """
        self.logger.info("Calling RaaS API to signal upgrade status [%s]", success)
        ret = self._raas_client.api.master.get_plugin_versions().ret
        self.logger.debug(
            "RaaS API to signal upgrade status. Return from API call: [%s]", ret
        )

    def _get_master_plugin_cache_directory(self, plugin_cache_directory=None):
        """
        Check for existence of directory where plugins downloaded from SSE are stored
        Typically, directory is something like "/var/cache/salt/master/plugin_cache"
        :param plugin_cache_directory:
        :return: full directory path
        """
        if not plugin_cache_directory:
            plugin_cache_directory = os.path.join(self.opts["cachedir"], "plugin_cache")

        return plugin_cache_directory

    def _start_background_monitor(self):
        # monitor upgrade from a subprocess
        process = multiprocessing.Process(
            target=self._monitor_and_finalize_upgrade, kwargs=self.opts
        )
        self.logger.info(
            "Starting new process [%s] to initiate master restart and complete plugin upgrade",
            process,
        )
        process.start()

    def upgrade(self):
        """
        Top-level orchestration workflow
        :return:
        """
        # upgrade/install .whl images
        num_upgraded = self._upgrade_plugins()
        self._start_background_monitor()

    def _configure_logger_for_multiprocessing(self, logger=None):
        """
        Configure logger with configuration suitable for workflow execution by this runner. Specifically,
        we want PIDs to show up in the log to be able to troubleshoot logging from multiple processes
        :return:
        """
        if not logger:
            self.logger = logging.getLogger(__name__)
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "PID-%(process)d %(asctime)s [%(levelname)s] %(message)s",
            "%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)


def upgrade(*args, **kwargs):
    """
    Perform an upgrade on the salt-master SSE plugins. This is the entry point into this runner.
    The upgrade process should be as idempotent as possible.

    A runner will be spawned in a thread under the master's process.
    As soon as that master goes down, this runner will die. Before that happens though,
    create a monitor process that will restart master and watch for completion.
    :return:_check_master_running_status_with_retry
    """

    logger.info("Starting upgrade of SSE plugins")
    master_plugin_upgrade_orch = MasterPluginUpgradeOrchestrator(args, kwargs)
    master_plugin_upgrade_orch.upgrade()
    logger.info("This runner will now exit. Upgrade handed off to a monitor subprocess")
