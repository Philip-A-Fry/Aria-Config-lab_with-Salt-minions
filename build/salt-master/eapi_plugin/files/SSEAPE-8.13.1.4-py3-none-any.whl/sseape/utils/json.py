# coding: utf-8
"""
JSON utils
"""

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
from __future__ import absolute_import
import numbers

# Import 3rd-party libs
import sseapiclient.serialize

# Import salt libs
try:
    from salt.utils.context import NamespacedDictWrapper

    HAS_NAMESPACED_DICT_WRAPPER = True
except ImportError:
    HAS_NAMESPACED_DICT_WRAPPER = False


class JSONEncoder(sseapiclient.serialize.JSONEncoder):
    """
    JSON encoder to handle salt's NamespacedDictWrapper
    """

    def default(self, obj):  # pylint: disable=method-hidden
        if HAS_NAMESPACED_DICT_WRAPPER and isinstance(obj, NamespacedDictWrapper):
            return obj._dict()  # pylint: disable=protected-access
        return super(JSONEncoder, self).default(obj)


def sanitize_bytes(data):
    """
    Walk though a JSON-compatible data structure, replacing non-utf-8 sequences
    in strings so they can be serialized to json. Ideally we would just replace
    these sequences during serialization by overriding Python's json string
    encoding, but the module doesn't allow for that.
    """

    def neq(a, b):
        """
        Avoid unicode warnings by checking types first
        """
        return type(a) != type(b) or a != b  # pylint: disable=unidiomatic-typecheck

    if isinstance(data, dict):
        for key, value in data.items():
            key2 = sanitize_bytes(key)
            value2 = sanitize_bytes(value)
            if neq(key2, key):
                data.pop(key)
                data[key2] = value2
            elif neq(value2, value):
                data[key] = value2
        return data
    if isinstance(data, list):
        for idx, item in enumerate(data):
            item2 = sanitize_bytes(item)
            if neq(item2, item):
                data[idx] = item2
        return data
    if isinstance(data, bytes):
        try:
            data = data.decode("utf-8")
        except UnicodeDecodeError:
            data = data.decode("utf-8", errors="replace")
        # continue now that data is a string
    if isinstance(data, str):
        # Remove null characters from strings
        data = data.replace("\x00", "")
    return data


def size_limited(data, limit, omit_none_kwargs=False):
    """
    If data is small and json-serializable, return it unchanged. Otherwise
    return a copy with the large parts and json-incompatible parts removed.
    This is basically a copy of audit_friendly() from raas.
    """
    limit = max(limit, 10)
    if data is None:
        return data
    if isinstance(data, numbers.Number):
        return data
    if isinstance(data, str):
        if len(data) < limit:
            return data
        return data[: limit - 5] + "..."
    if isinstance(data, dict):
        if omit_none_kwargs:
            data = {k: v for k, v in data.items() if v is not None}
        if len(data) <= limit / 10:
            data2 = {
                size_limited(k, limit): size_limited(v, limit) for k, v in data.items()
            }
            return data if data2 == data else data2
        return "{<truncated>}"
    if isinstance(data, (list, set)):
        if len(data) <= limit / 10:
            data2 = [size_limited(item, limit) for item in data]
            return data if data2 == data else data2
        return "[<truncated>]"
    return str(type(data))
