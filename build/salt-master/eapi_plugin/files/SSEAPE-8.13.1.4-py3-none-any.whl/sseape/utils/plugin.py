# coding: utf-8
import logging
import os
import traceback
from collections import namedtuple

import salt.syspaths
import salt.loader
import salt.utils.event
import salt._logging
import salt.client
import salt.config
import salt.utils.process
import salt.exceptions
import salt.ext.tornado.ioloop
import salt.utils.files
import salt.utils.hashutils
import sseape.version

from sseape.utils.client import make_api_client, get_pillar

log = logging.getLogger(__name__)

MasterPluginUpdateStatus = namedtuple(
    "MasterPluginUpdateStatus",
    field_names=[
        "UP_TO_DATE",
        "NEEDS_UPDATE",
        "CANNOT_UPDATE",
        "UPGRADING",
        "RESTARTING",
        "UPGRADE_FAILED",
        "ROLLBACK_FAILED_DISCONNECTED",
    ],
)(
    "up_to_date",
    "needs_update",
    "cannot_update",
    "upgrading",
    "restarting",
    "upgrade_failed",
    "rollback_failed_disconnected",
)


class MasterPluginManager:
    """
    Handles Salt Master Plugin update lifecycle.
    """

    def __init__(self, master_opts, runners):
        self.master_opts = master_opts
        self.runners = runners

        # Init salt clients.
        self.caller = None
        self.init_salt_clients()

        # Init raas clients
        self.raas_rpc_client, self.raas_http_client = None, None

        self.jid = None

        # Store the current update state to a file
        self.plugin_cache_dir = os.path.join(
            self.master_opts["cachedir"], "plugin_cache"
        )
        os.makedirs(self.plugin_cache_dir, exist_ok=True)

        self.plugin_update_state_file = os.path.join(
            self.plugin_cache_dir, ".update_state_file"
        )

        log.info("%s is now initialized.", self.__class__.__name__)

    def init_salt_clients(self):
        log.info("Initializing salt clients.")
        self.caller = self.runners["salt.cmd"]
        log.info("Salt clients initialized successfully.")

    def init_raas_clients(self):
        log.info("Initializing raas clients for JID: [%s]", self.jid)
        pillar = get_pillar(opts=self.master_opts, runners=self.runners)
        self.raas_rpc_client = make_api_client(opts=self.master_opts, pillar=pillar)
        log.debug("raas rpc client created successfully for JID: [%s]", self.jid)
        self.raas_http_client = self.raas_rpc_client.httpclient
        log.info("raas clients initialized successfully for JID: [%s]", self.jid)

    def restart_service(self, name):
        """
        Restart the given service via salt state module.
        """
        jid = self.jid
        log.info("Restarting service [%s] for JID: [%s].", name, jid)
        # This code restarts the salt-master when invoked from the runner.
        # The runner will not return and will end with a `salt.ext.tornado.iostream.StreamClosedError: Stream is closed`
        # traceback. The JID will show as "running" in the UI.
        # The below code follows the watch pattern as documented here:
        # https://docs.saltproject.io/en/latest/ref/states/requisites.html#requisites
        # Instead of watching a file or a package, we simply trigger an event with test.suceed_with_changes,
        # as salt does not have documentation for service.running to be used in this manner.
        ret = self._salt_call(
            "state.high",
            {
                name: {
                    "service": [
                        "running",
                        {
                            "init_delay": int(
                                self.master_opts.get("sseapi_service_init_delay", 10)
                            )
                        },
                        {"watch": [{"test": "trigger"}]},
                    ]
                },
                "trigger": {"test": ["succeed_with_changes"]},
            },
        )

    def get_installed_version(self):
        log.info("Getting currently installed plugin version")
        ver = None
        try:
            ver = sseape.version.BUILDINFO.get("git_describe", "").strip()
            if not ver:
                raise salt.exceptions.SaltException(
                    "Unable to find installed SSEAPE version"
                )
        except Exception as exc:  # pylint: disable=broad-except
            log.error("Failed getting installed SSEAPE version: %s", exc)
            raise
        return ver

    def needs_update(self, metadata):
        log.info(
            "Comparing versions between latest and currently installed plugin. Metadata: [%s]",
            metadata,
        )
        installed = self.get_installed_version()
        current = str(metadata["current"]["git_describe"]).lstrip("v")
        log.info("Installed version: %s. Latest version: %s", installed, current)
        return installed != current

    def update_in_progress(self):
        log.info(
            "Checking for updates currently in progress. [%s]",
            self.plugin_update_state_file,
        )
        return os.path.exists(self.plugin_update_state_file)

    def save_plugin_update_jid(self):
        log.info(
            "Saving the JID in update state file [%s]", self.plugin_update_state_file
        )
        if self.jid:
            with salt.utils.files.fopen(self.plugin_update_state_file, "w") as fp:
                fp.write(self.jid)

    def refresh_plugin_update_jid(self):
        log.info("Refreshing the JID from the plugin update state file")
        if self.update_in_progress():
            with salt.utils.files.fopen(self.plugin_update_state_file, "r") as fp:
                jid = fp.read()
                if jid:
                    self.jid = jid

    def delete_plugin_update_jid(self):
        log.info(
            "Deleting plugin update state file [%s]", self.plugin_update_state_file
        )
        if os.path.exists(self.plugin_update_state_file):
            os.unlink(self.plugin_update_state_file)

    def update(self, jid=None, allow_plugin_update=True):
        """
        Common routine to update the plugin and the status to raas
        """
        log.info(
            "Running plugin manager update routines. jid: [%s], allow_plugin_update: [%s]",
            jid,
            allow_plugin_update,
        )

        ret, self.jid, log_messages = None, jid, None
        try:
            # Initialize raas clients just for the plugin update transaction.
            self.init_raas_clients()

            # Updating plugin
            try:
                in_progress = self.update_in_progress()
                # This condition will only be met by the engine.
                if in_progress and allow_plugin_update is False:
                    self.refresh_plugin_update_jid()
                    self.delete_plugin_update_jid()
                metadata = self.get_plugin_metadata()
                needs_update = self.needs_update(metadata)
                if needs_update:
                    self.update_status(status=MasterPluginUpdateStatus.NEEDS_UPDATE)
                    # Don't allow accidental updates
                    if not in_progress and allow_plugin_update:
                        updated = self.update_plugin(metadata=metadata)
                        if updated:
                            self.save_plugin_update_jid()
                            self.update_status(
                                status=MasterPluginUpdateStatus.RESTARTING
                            )
                            self.restart_service(name="salt-master")
                else:
                    self.update_status(status=MasterPluginUpdateStatus.UP_TO_DATE)
                ret = self.jid
            except Exception as exc:  # pylint: disable=broad-except
                ret = traceback.format_exc()
                self.update_status(
                    status=MasterPluginUpdateStatus.UPGRADE_FAILED,
                    log_messages=ret,
                )
                log.exception("Unable to update plugin. Error: %s.", exc)
        except Exception as exc:  # pylint: disable=broad-except
            log.warning(
                "Encountered an exception in the current iteration. Exception: [%s]",
                exc,
            )
            ret = traceback.format_exc()
        finally:
            self.delete_raas_clients()
        return ret

    def delete_raas_clients(self):
        log.info("Deleting raas clients.")
        if hasattr(self, "raas_rpc_client"):
            del self.raas_rpc_client

    def _salt_call(self, fun, *args, **kwargs):
        """
        Runs the equivalent of "salt-run salt.cmd"
        """
        log.info(
            "JID: [%s]. Running the equivalent of: salt-run salt.cmd %s %s %s",
            self.jid,
            fun,
            " ".join([str(i) for i in args]),
            " ".join([f"{k}={v}" for k, v in kwargs.items()]),
        )
        result = self.caller(fun, *args, **kwargs)
        log.info("salt.cmd result: %s", result)

        # The response needs to be inspected for each salt module called.
        # If no response inspectors found for a given module, the response will be returned as-is for the
        # caller to do the error handling.
        if fun == "pip.install":
            if (
                isinstance(result, dict)
                and result
                and "retcode" in result
                and not result["retcode"]
            ):
                return result
        elif fun == "state.high":
            if (
                isinstance(result, dict)
                and result
                and all(map(lambda x: x.get("result"), list(result.values())))
            ):
                return result
        elif fun == "pip.list":
            if result and isinstance(result, dict):
                return result
        else:
            return result
        raise salt.exceptions.SaltException(
            f"salt-call:: fun: [{fun}], args: [{args}], kwargs: [{kwargs}] failed with result {result}"
        )

    def pip_install(self, plugin):
        """
        Install the salt master plugin using salt.pip exec module
        """
        log.info("JID: [%s]. Installing salt master plugin [%s]", self.jid, plugin)
        pip_args = self.master_opts.get("sseapi_pip_install_args", {})
        self._salt_call("pip.install", plugin, **pip_args)
        log.info(
            "JID: [%s]. Salt master plugin [%s] updated successfully", self.jid, plugin
        )

    def download_plugin(self, plugin_name):
        log.info(
            "Downloading plugin from raas for JID: [%s], plugin: [%s]",
            self.jid,
            plugin_name,
        )
        plugin_cache_dir = os.path.join(self.master_opts["cachedir"], "plugin_cache")
        plugin = os.path.join(plugin_cache_dir, plugin_name)
        if not os.path.exists(plugin):
            log.info("Caching plugin [%s] at [%s]", plugin_name, plugin_cache_dir)
            os.makedirs(plugin_cache_dir, exist_ok=True)
            data = self.raas_http_client.fetch(
                url="/master_plugins/{}".format(plugin_name)
            )
            with salt.utils.files.fopen(plugin, "wb") as fp:
                fp.write(data)
        return plugin

    def get_plugin_metadata(self):
        log.info("Retrieving plugin metadata from raas for JID: [%s]", self.jid)
        ret = self.raas_rpc_client.api.master.get_plugin_versions().ret
        log.info("Available plugin versions: %s", ret)
        if not ret:
            raise salt.exceptions.SaltException("No plugins found in raas")
        return ret

    def get_plugin(self, metadata):
        log.info(
            "Retrieving plugin metadata from raas for JID: [%s], metadata: [%s]",
            self.jid,
            metadata,
        )
        meta_hash = metadata.get("current", {}).get("sha256")
        plugin_name = metadata.get("current", {}).get("filename")
        plugin = self.download_plugin(plugin_name)

        # Validate hash
        hash = salt.utils.hashutils.get_hash(plugin, form="sha256")
        if hash != meta_hash:
            raise salt.exceptions.SaltException(
                f"Plugin hash mismatch. Expected {meta_hash}, got {hash}"
            )
        return plugin

    def update_plugin(self, metadata):
        """
        Install/upgrade new plugin .whl images
        """
        log.info(
            "Updating the plugin for JID: [%s], metadata: [%s]", self.jid, metadata
        )
        plugin = self.get_plugin(metadata=metadata)
        self.update_status(status=MasterPluginUpdateStatus.NEEDS_UPDATE)
        self.pip_install(plugin=plugin)
        return True

    def update_status(self, status, log_messages=None):
        """
        Calls RaaS API to set plugin update status
        """
        log.info(
            "JID: [%s]. Calling RaaS API to set plugin update status [%s], log_messages [%s]",
            self.jid,
            status,
            log_messages,
        )
        ret = self.raas_rpc_client.api.master.set_plugin_status(
            master_id=self.master_opts["id"],
            status=status,
            last_update_jid=self.jid,
            log_messages=log_messages,
        ).ret
        log.debug(
            "JID: [%s]. RaaS API to set plugin update status. Return from API call: [%s]",
            self.jid,
            ret,
        )
        return ret
