# coding: utf-8
"""
Utility function to join a salt-master to Config on cloud.
"""

# Copyright (C) 2023 VMware, Inc.
#

import logging
import os
import sys

import salt.syspaths

import sseape.version
from sseape.utils.access import is_connected_to_ssc
from sseape.utils.csp import CSP


class JoinSSC:
    """
    Workflow to join this master to SSC Cloud instance
    Creates the necessary CSP constructs, creates pillar with CSP secret that can be used by master to talk to
    the raas instance in the cloud
    """

    # class-level variable contains master config opts
    MASTER_OPTS = {}
    # class-level variable contains CSP pillar opts
    CSP_PILLAR_OPTS = {}

    logger = logging.getLogger(__name__)

    @staticmethod
    def run(
        csp_base_url: str,
        log_level: str = "INFO",
        override_oauth_app: bool = False,
        **kwargs,
    ):
        JoinSSC._configure_logger(logging.getLogger(__name__), log_level)

        JoinSSC.logger.info(
            "SSEAPE joining SSC Cloud... %s %s",
            sseape.version.BUILDINFO["git_describe"],
            sseape.version.BUILDINFO["build_date"],
        )
        csp_api_token = JoinSSC.get_validate_env()
        csp = CSP(csp_base_url, csp_api_token, logger=JoinSSC.logger)

        # grab the prerequisites for communicating with CSP
        JoinSSC.logger.info("Retrieving CSP auth token.")
        csp_access_token = (
            os.getenv("CSP_ACCESS_TOKEN") or csp.get_auth_token_from_api_token()
        )
        csp.validate_access_token(csp_access_token)
        csp_org_id = csp.get_org_id_from_csp_access_token(csp_access_token)

        csp_service_definition_id = csp.get_csp_ssc_service_definition_id(
            csp_access_token
        )

        # create/update service app
        oauth_app = csp.get_oauth_app_by_name(
            csp_access_token, csp_service_definition_id
        )
        if oauth_app:
            if override_oauth_app:
                JoinSSC.logger.info(
                    "Deleting oauth app [%s] with id [%s] and recreating it.",
                    oauth_app["displayName"],
                    oauth_app["id"],
                )
                csp.delete_agent_oauth_app(csp_access_token, oauth_app["id"])
                oauth_app_secret = csp.create_agent_oauth_app(
                    csp_access_token, csp_service_definition_id
                )
                oauth_app = csp.get_oauth_app_by_name(
                    csp_access_token, csp_service_definition_id
                )
            else:
                JoinSSC.logger.info(
                    "Updating oauth app [%s] with new secret.", oauth_app["displayName"]
                )
                oauth_app_secret = csp.recreate_agent_oauth_app_secret(
                    csp_access_token, oauth_app["id"]
                )
        else:
            JoinSSC.logger.info("Creating new oauth app.")
            oauth_app_secret = csp.create_agent_oauth_app(
                csp_access_token, csp_service_definition_id
            )
            oauth_app = csp.get_oauth_app_by_name(
                csp_access_token, csp_service_definition_id
            )

        csp_client_id = oauth_app_secret["clientId"]
        csp_client_secret = oauth_app_secret["clientSecret"]
        JoinSSC.logger.info(
            "Finished with oauth app [%s] in org [%s].",
            oauth_app["displayName"],
            csp_org_id,
        )

        # create/update service role
        role_name = csp.add_oauth_app_service_role(
            csp_access_token, csp_client_id, csp_service_definition_id
        )
        JoinSSC.logger.info(
            "Added service role [%s] for oauth app [%s].",
            role_name,
            oauth_app["displayName"],
        )

        # create/update pillar with secrets
        pillar_name, JoinSSC.CSP_PILLAR_OPTS = csp.create_update_csp_pillar(
            csp_client_id, csp_client_secret, csp_org_id
        )
        JoinSSC.logger.info("Created pillar [%s].", pillar_name)

        # update master config to point to pillar
        JoinSSC.MASTER_OPTS = csp.update_master_csp_conf()
        JoinSSC.MASTER_OPTS.update(kwargs)
        JoinSSC.logger.info(
            "Updated master config. Please restart master for config changes to take effect."
        )

        # update cloud.conf to point to the SSC instance
        csp.update_cloud_conf(sseapi_server=JoinSSC.MASTER_OPTS.get("sseapi_server"))
        JoinSSC.logger.info("Updated master cloud.conf.")

        # Setting ownership of master config and pillar files
        # Salt Master in v3006.x run as "salt" user by default.
        user = JoinSSC.MASTER_OPTS["user"]
        JoinSSC.logger.info("Setting config and pillar ownership to user [%s].", user)
        master_config_dir = os.path.join(
            salt.syspaths.CONFIG_DIR,
            os.path.dirname(JoinSSC.MASTER_OPTS["default_include"]),
        )
        pillar_roots = JoinSSC.MASTER_OPTS["pillar_roots"].get("base", [])
        pillar_dirs = []
        for pr in pillar_roots:
            if os.path.exists(pr):
                pillar_dirs.append(pr)
        os.system(f"chown -R {user}:{user} {' '.join(pillar_dirs)} {master_config_dir}")

        # complete joining SaltStack Cloud instance
        JoinSSC.validate_and_complete_join_saltstack_instance(
            opts=JoinSSC.MASTER_OPTS,
            pillar=JoinSSC.CSP_PILLAR_OPTS,
            logger=JoinSSC.logger,
        )

    @staticmethod
    def get_validate_env():
        """
        Validates presence of the minimum set of environment variables to start communicating with CSP
        :return: CSP_API_TOKEN (previously known as "refresh token")
        """
        token = os.getenv("CSP_API_TOKEN") or os.getenv("CSP_ACCESS_TOKEN")
        if not token:
            raise ValueError("CSP_API_TOKEN or CSP_ACCESS_TOKEN must be set")

        return token

    @staticmethod
    @is_connected_to_ssc
    def validate_and_complete_join_saltstack_instance(**kwargs):
        """
        Validate connectivity to SSC instance and log completion of join operation, if successful
        """
        JoinSSC.logger.info(
            "Finished SSEAPE joining SSC Cloud... %s %s",
            sseape.version.BUILDINFO["git_describe"],
            sseape.version.BUILDINFO["build_date"],
        )

    @staticmethod
    def _configure_logger(logger, log_level):
        """
        Configure logger with configuration suitable for workflow execution by this class
        :param logger:
        :return:
        """
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(log_level)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
