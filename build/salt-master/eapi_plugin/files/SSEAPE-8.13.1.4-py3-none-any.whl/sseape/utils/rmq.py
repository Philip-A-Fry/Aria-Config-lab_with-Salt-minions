# -- coding: utf-8 -*-
# pylint: disable=C0111,C0103,R0205
#
# Utility class for publishing messages to RMQ
#
# Adapted from https://github.com/pika/pika/blob/master/examples/asynchronous_publisher_example.py
# and https://github.com/pika/pika/blob/master/examples/asynchronous_consumer_example.py

# Import Python libs
from __future__ import absolute_import
import functools
import logging
import json
import secrets
import time

# Import 3rd-party libs
import pika
import pika.adapters
from pika.adapters.select_connection import SelectConnection
from pika.exchange_type import ExchangeType

# Import salt libs
import salt.ext.tornado
import salt.ext.tornado.gen
import salt.ext.tornado.platform.asyncio

# Import SSEAPE libs
import sseape.utils.config as sseape_config

log = logging.getLogger(__name__)

__salt__ = None


class SaltRMQPubsub(object):
    """This publisher will handle unexpected interactions
    with RabbitMQ such as channel and connection closures.
    If RabbitMQ closes the connection, it will reopen it. You should
    look at the output, as there are limited reasons why the connection may
    be closed, which usually are tied to permission related issues or
    socket timeouts.
    """

    ITERATE_INTERVAL = 1

    def __init__(self, amqp_url=None, opts=None, io_loop=None, eqe=None):
        """Setup the example publisher object, passing in the URL we will use
        to connect to RabbitMQ.
        :param str amqp_url: The URL for connecting to RabbitMQ
        """
        global __salt__
        if __salt__ is None:
            __salt__ = salt.loader.minion_mods(opts)

        def get_config(name):
            return sseape_config.get(
                self.opts, "{}.{}".format(self.eqe.config_name, name)
            )

        self._connection = None

        self._published_messages_pending_ack_from_broker = None
        self._acked = None
        self._nacked = None
        self._message_number = None
        self._prefetch_count = opts.get("sseapi_event_queue").get(
            "amqp_subscribe_prefetch_count", 1
        )

        self._closing = False
        self._stopping = False
        self._url = opts.get("sseapi_event_queue").get("amqp_url")
        self.pub_exchange_name = opts.get("sseapi_event_queue").get(
            "amqp_publish_exchange"
        )
        self.sub_exchange_name = opts.get("sseapi_event_queue").get(
            "amqp_subscribe_exchange"
        )
        self.sub_queue_name = f"sub-{opts.get('id', secrets.token_hex(8))}"
        self.opts = opts
        self.io_loop = io_loop
        self.eqe = eqe
        self.pub_channel = None
        self.sub_channel = None
        self.push_interval = get_config("push_interval")
        self.queue_options = get_config("amqp_queue_options")
        self.local = salt.client.get_local_client(io_loop=self.io_loop)
        self.EXCHANGE_TYPE = ExchangeType.fanout

    def connect(self):
        """This method connects to RabbitMQ, returning the connection handle.
        When the connection is established, the on_connection_open method
        will be invoked by pika.
        :rtype: pika.TornadoConnection
        """
        log.info("AMQP Connecting to %s", self._url)
        return SelectConnection(
            pika.URLParameters(self._url),
            on_open_callback=self.on_connection_open,
            on_open_error_callback=self.on_connection_open_error,
            on_close_callback=self.on_connection_closed,
        )

    def on_connection_open(self, _unused_connection):
        """This method is called by pika once the connection to RabbitMQ has
        been established. It passes the handle to the connection object in
        case we need it, but in this case, we'll just mark it unused.
        :param pika.SelectConnection _unused_connection: The connection
        """
        log.info("AMQP Connection opened")
        self.open_channels()

    def on_connection_open_error(self, _unused_connection, err):
        """This method is called by pika if the connection to RabbitMQ
        can't be established.
        :param pika.SelectConnection _unused_connection: The connection
        :param Exception err: The error
        """
        log.error("AMQP Connection open failed, reopening in 5 seconds: %s", err)
        self._connection.ioloop.call_later(5, self._connection.ioloop.stop)

    def on_connection_closed(self, _unused_connection, reason):
        """This method is invoked by pika when the connection to RabbitMQ is
        closed unexpectedly. Since it is unexpected, we will reconnect to
        RabbitMQ if it disconnects.
        :param pika.connection.Connection connection: The closed connection obj
        :param Exception reason: exception representing reason for loss of
            connection.
        """
        self.pub_channel = None
        self.sub_channel = None
        if self._stopping:
            self._connection.ioloop.stop()
        else:
            log.warning("Connection closed, reopening in 5 seconds: %s", reason)
            self._connection.ioloop.call_later(5, self._connection.ioloop.stop)

    def open_channels(self):
        """This method will open a new channel with RabbitMQ by issuing the
        Channel.Open RPC command. When RabbitMQ confirms the channel is open
        by sending the Channel.OpenOK RPC reply, the on_channel_open method
        will be invoked.
        """
        log.info("Creating publish and subscribe channels")
        self._connection.channel(on_open_callback=self.on_pub_channel_open)
        self._connection.channel(on_open_callback=self.on_sub_channel_open)

    def on_pub_channel_open(self, channel):
        """This method is invoked by pika when the channel has been opened.
        The channel object is passed in so we can make use of it.
        Since the channel is now open, we'll declare the exchange to use.
        :param pika.channel.Channel channel: The channel object
        """
        log.info("Publish channel opened")
        self.pub_channel = channel
        self.add_on_pub_channel_close_callback()
        self.setup_pub_exchange(self.pub_exchange_name)

    def on_sub_channel_open(self, channel):
        """This method is invoked by pika when the channel has been opened.
        The channel object is passed in so we can make use of it.
        Since the channel is now open, we'll declare the exchange to use.
        :param pika.channel.Channel channel: The channel object
        """
        log.info("Subscribe channel opened")
        self.sub_channel = channel
        self.add_on_sub_channel_close_callback()
        self.setup_sub_exchange(self.sub_exchange_name)

    def add_on_pub_channel_close_callback(self):
        """This method tells pika to call the on_channel_closed method if
        RabbitMQ unexpectedly closes the channel.
        """
        log.info("Adding publish channel close callback")
        self.pub_channel.add_on_close_callback(self.on_channel_closed)

    def add_on_sub_channel_close_callback(self):
        """This method tells pika to call the on_channel_closed method if
        RabbitMQ unexpectedly closes the channel.
        """
        log.info("Adding subscribe channel close callback")
        self.sub_channel.add_on_close_callback(self.on_channel_closed)

    def on_channel_closed(self, channel, reason):
        """Invoked by pika when RabbitMQ unexpectedly closes the channel.
        Channels are usually closed if you attempt to do something that
        violates the protocol, such as re-declare an exchange or queue with
        different parameters. In this case, we'll close the connection
        to shutdown the object.
        :param pika.channel.Channel channel: The closed channel
        :param Exception reason: why the channel was closed
        """
        log.warning("Channel %i was closed: %s", channel, reason)
        self.sub_channel = None
        if not self._stopping:
            if not self._connection.is_closed:
                self._connection.close()

    def add_on_cancel_callback(self):
        """Add a callback that will be invoked if RabbitMQ cancels the consumer
        for some reason. If RabbitMQ does cancel the consumer,
        on_consumer_cancelled will be invoked by pika.
        """
        log.info("Adding consumer cancellation callback")
        self.sub_channel.add_on_cancel_callback(self.on_consumer_cancelled)

    def on_consumer_cancelled(self, method_frame):
        """Invoked by pika when RabbitMQ sends a Basic.Cancel for a consumer
        receiving messages.
        :param pika.frame.Method method_frame: The Basic.Cancel frame
        """
        log.info("Consumer was cancelled remotely, shutting down: %r", method_frame)
        if self.sub_channel:
            self.sub_channel.close()

    def setup_pub_exchange(self, exchange_name):
        """Setup the exchange on RabbitMQ by invoking the Exchange.Declare RPC
        command. When it is complete, the on_exchange_declareok method will
        be invoked by pika.
        :param str|unicode exchange_name: The name of the exchange to declare
        """
        log.info("Declaring exchange %s", exchange_name)
        # Note: using functools.partial is not required, it is demonstrating
        # how arbitrary data can be passed to the callback when it is called
        cb = functools.partial(self.on_pub_exchange_declareok, userdata=exchange_name)
        chan = self.pub_channel

        chan.exchange_declare(
            exchange=exchange_name,
            exchange_type=self.EXCHANGE_TYPE,
            durable=True,
            callback=cb,
        )

    def setup_sub_exchange(self, exchange_name):
        """Setup the exchange on RabbitMQ by invoking the Exchange.Declare RPC
        command. When it is complete, the on_exchange_declareok method will
        be invoked by pika.
        :param str|unicode exchange_name: The name of the exchange to declare
        """
        log.info("Declaring exchange %s", exchange_name)
        # Note: using functools.partial is not required, it is demonstrating
        # how arbitrary data can be passed to the callback when it is called
        cb = functools.partial(self.on_sub_exchange_declareok, userdata=exchange_name)
        chan = self.sub_channel

        chan.exchange_declare(
            exchange=exchange_name,
            exchange_type=self.EXCHANGE_TYPE,
            durable=True,
            callback=cb,
        )

    def on_pub_exchange_declareok(self, _unused_frame, userdata):
        """Invoked by pika when RabbitMQ has finished the Exchange.Declare RPC
        command.
        :param pika.Frame.Method unused_frame: Exchange.DeclareOk response frame
        :param str|unicode userdata: Extra user data (exchange name)
        """
        log.info("Exchange declared: %s", userdata)
        self.start_publishing()

    def on_sub_exchange_declareok(self, _unused_frame, userdata):
        """Invoked by pika when RabbitMQ has finished the Exchange.Declare RPC
        command.
        :param pika.Frame.Method unused_frame: Exchange.DeclareOk response frame
        :param str|unicode userdata: Extra user data (exchange name)
        """
        log.info("Exchange declared: %s", userdata)
        self.setup_sub_queue(self.sub_queue_name)

    def setup_sub_queue(self, queue_name):
        """Setup the queue on RabbitMQ by invoking the Queue.Declare RPC
        command. When it is complete, the on_queue_declareok method will
        be invoked by pika.
        :param str|unicode queue_name: The name of the queue to declare.
        """
        log.info("Declaring queue %s", queue_name)
        if not self.sub_channel:
            raise ValueError("sub_channel must be set when declaring queue")

        self.sub_channel.queue_declare(
            queue=queue_name,
            durable=True,
            auto_delete=False,
            arguments=self.queue_options,
            callback=self.on_sub_queue_declareok,
        )

    def on_sub_queue_declareok(self, _unused_frame):
        """Method invoked by pika when the Queue.Declare RPC call made in
        setup_queue has completed. In this method we will bind the queue
        and exchange together with the routing key by issuing the Queue.Bind
        RPC command. When this command is complete, the on_bindok method will
        be invoked by pika.
        :param pika.frame.Method method_frame: The Queue.DeclareOk frame
        """
        log.info("Binding %s to %s", self.sub_exchange_name, self.sub_queue_name)
        if not self.sub_channel:
            raise ValueError("sub_channel must be set when binding queue to exchange")

        self.sub_channel.queue_bind(
            self.sub_queue_name, self.sub_exchange_name, callback=self.on_sub_bindok
        )

    def on_sub_bindok(self, _unused_frame):
        """This method is invoked by pika when it receives the Queue.BindOk
        response from RabbitMQ. Since we know we're now setup and bound, it's
        time to start publishing."""
        log.info("Subscribe Queue bound")
        self.set_qos(self.sub_channel)

    def start_publishing(self):
        """This method will schedule the first message to be sent to RabbitMQ"""
        log.info("Issuing publisher related RPC commands")
        self.schedule_next_message()
        # see https://www.rabbitmq.com/confirms.html#publisher-confirms
        self.enable_delivery_confirmations()

    def set_qos(self, channel):
        """This method sets up the consumer prefetch to only be delivered
        one message at a time. The consumer must acknowledge this message
        before RabbitMQ will deliver another one. You should experiment
        with different prefetch values to achieve desired performance.
        """
        channel.basic_qos(
            prefetch_count=self._prefetch_count, callback=self.on_basic_qos_ok
        )

    def on_basic_qos_ok(self, _unused_frame):
        """Invoked by pika when the Basic.QoS method has completed. At this
        point we will start consuming messages by calling start_consuming
        which will invoke the needed RPC commands to start the process.
        :param pika.frame.Method _unused_frame: The Basic.QosOk response frame
        """
        log.info("Channel QOS prefetch count set to: %d", self._prefetch_count)
        self.start_consuming()

    def start_consuming(self):
        """This method sets up the consumer by first calling
        add_on_cancel_callback so that the object is notified if RabbitMQ
        cancels the consumer. It then issues the Basic.Consume RPC command
        which returns the consumer tag that is used to uniquely identify the
        consumer with RabbitMQ. We keep the value to use it when we want to
        cancel consuming. The on_message method is passed in as a callback pika
        will invoke when a message is fully received.
        """
        log.info("Issuing consumer related RPC commands")
        self.add_on_cancel_callback()
        self._consumer_tag = self.sub_channel.basic_consume(
            self.sub_queue_name, self.on_message
        )
        self.was_consuming = True
        self._consuming = True

    def format_and_forward_event(self, data):
        """
        Take the now clear load and forward it on to the client cmd.
        This code is mostly lifted from Syndics
        """

        def timeout_handler(*args):
            log.warning("rmq--Unable to forward pub data: %s", args[1])
            return True

        tag = data.get("tag")
        payload = data.get("data", {})
        master_path = set(payload.get("_master_path", []))
        if self.opts.get("id") not in master_path:
            master_path.add(self.opts.get("id"))
            payload["_master_path"] = list(master_path)
            with salt.utils.event.get_event("master", opts=self.opts) as evt:
                evt.fire_event(payload, tag)

    def on_message(self, _unused_channel, basic_deliver, properties, body):
        """Invoked by pika when a message is delivered from RabbitMQ. The
        channel is passed for your convenience. The basic_deliver object that
        is passed in carries the exchange, routing key, delivery tag and
        a redelivered flag for the message. The properties passed in is an
        instance of BasicProperties with the message properties and the body
        is the message that was sent.
        :param pika.channel.Channel _unused_channel: The channel object
        :param pika.Spec.Basic.Deliver: basic_deliver method
        :param pika.Spec.BasicProperties: properties
        :param bytes body: The message body
        """
        log.info(
            "Received message # %s from %s: %s",
            basic_deliver.delivery_tag,
            properties.app_id,
            body,
        )

        # if the master this message came from is this master,
        # ack it but don't put it on the zmq bus
        if properties.headers.get("source_master") != self.opts.get("id"):
            # ok looks good, extract data and put on bus
            payload = json.loads(body)
            self.format_and_forward_event(payload["data"])
        self.acknowledge_message(basic_deliver.delivery_tag)

    def acknowledge_message(self, delivery_tag):
        """Acknowledge the message delivery from RabbitMQ by sending a
        Basic.Ack RPC method for the delivery tag.
        :param int delivery_tag: The delivery tag from the Basic.Deliver frame
        """
        log.info("Acknowledging message %s", delivery_tag)
        # consider switching to batch ack mode as an optimization
        # this would require processing multiple message in a batch and then
        # sending a single ack for the entire batch
        self.sub_channel.basic_ack(delivery_tag, multiple=False)

    def schedule_next_message(self):
        """If we are not closing our connection to RabbitMQ, schedule another
        message to be delivered in push_interval seconds.
        """
        log.info("Scheduling next message for %0.1f seconds", self.push_interval)
        self._connection.ioloop.call_later(self.push_interval, self.entry_iterate)

    def enable_delivery_confirmations(self):
        """Send the Confirm.Select RPC method to RabbitMQ to enable delivery
        confirmations on the channel. The only way to turn this off is to close
        the channel and create a new one.
        When the message is confirmed from RabbitMQ, the
        on_delivery_confirmation method will be invoked passing in a Basic.Ack
        or Basic.Nack method from RabbitMQ that will indicate which messages it
        is confirming or rejecting.
        """
        log.info("Issuing Confirm.Select RPC command for pub delivery confirmation")
        self.pub_channel.confirm_delivery(self.on_delivery_confirmation)

    def on_delivery_confirmation(self, method_frame):
        """Invoked by pika when RabbitMQ responds to a Basic.Publish RPC
        command, passing in either a Basic.Ack or Basic.Nack frame with
        the delivery tag of the message that was published. The delivery tag
        is an integer counter indicating the message number that was sent
        on the channel via Basic.Publish. Here we're just doing house keeping
        to keep track of stats and remove message numbers that we expect
        a delivery confirmation of from the list used to keep track of messages
        that are pending confirmation.
        NOTE: at some point you would check self._published_messages_pending_ack_from_broker for stale
            entries and decide to attempt re-delivery
        :param pika.frame.Method method_frame: Basic.Ack or Basic.Nack frame
        """
        confirmation_type = method_frame.method.NAME.split(".")[1].lower()
        ack_multiple = method_frame.method.multiple
        delivery_tag = method_frame.method.delivery_tag

        log.info(
            "Received %s for delivery tag: %i (multiple: %s)",
            confirmation_type,
            delivery_tag,
            ack_multiple,
        )
        if confirmation_type == "ack":
            # https://www.rabbitmq.com/confirms.html#publisher-confirms
            # For routable messages, the basic.ack is sent when a message has been accepted by all the queues
            self._acked += 1
        elif confirmation_type == "nack":
            # https://www.rabbitmq.com/confirms.html#publisher-confirms
            # basic.nack will only be delivered if an
            # internal error occurs in the Erlang process responsible for a queue.
            self._nacked += 1

        del self._published_messages_pending_ack_from_broker[delivery_tag]

        if ack_multiple:
            for tmp_tag in list(
                self._published_messages_pending_ack_from_broker.keys()
            ):
                if tmp_tag <= delivery_tag:
                    self._acked += 1
                    del self._published_messages_pending_ack_from_broker[tmp_tag]

        log.info(
            "Published %i messages, %i have yet to be confirmed, "
            "%i were acked and %i were nacked",
            self._message_number,
            len(self._published_messages_pending_ack_from_broker.keys()),
            self._acked,
            self._nacked,
        )

    def send_entries(self, entries):
        """
        Publish to RabbitMQ,
        appending a list of deliveries with the message number that was sent.
        This list will be used to check for delivery confirmations in the
        on_delivery_confirmations method.
        Once the message has been sent, schedule another message to be sent.
        """
        if self.pub_channel is None or not self.pub_channel.is_open:
            return

        properties = pika.BasicProperties(
            app_id="salt",
            content_type="application/json",
            headers={"source_master": self.opts["id"]},
            delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE,
        )

        tot = len(entries)
        log.info("Publishing a batch of %i events", tot)
        for i in entries:
            self.pub_channel.basic_publish(
                self.pub_exchange_name,
                "ignored",
                json.dumps(i, ensure_ascii=False),
                properties=properties,
                mandatory=True,
            )
            self._message_number += 1
            self._published_messages_pending_ack_from_broker[
                self._message_number
            ] = True
            log.info("rmq-- Published message # %i", self._message_number)

        return max([item["timestamp"] for item in entries])

    def stopping(self):
        return self._stopping

    def entry_iterate(self):
        log.info("Start %s engine iteration...", self.eqe.config_name)
        if not __salt__["sseapi_local_queue.queue_exists"](self.eqe.name):
            log.info(
                "%s: primary queue does not exist, skipping this iteration",
                self.eqe.config_name,
            )
            return self.eqe.push_interval

        start = time.time()
        try:
            self.eqe._process_entries()
            self.eqe._forward_entries()
            self.eqe._vacuum_if_due()
        except Exception as exc:  # pylint: disable=broad-except
            log.info(
                "%s: engine iteration interrupted with exception: %s",
                self.eqe.config_name,
                exc,
                exc_info=True,
            )
        duration = time.time() - start

        # If the iteration ran longer than the interval, sleep a little anyway
        stime = self.eqe.push_interval - duration
        if stime < 0:
            log.warning(
                "%s: engine iteration time (%.1fs) exceeded push interval (%.1fs)",
                self.eqe.config_name,
                duration,
                self.eqe.push_interval,
            )
            stime = min(5, self.eqe.push_interval / 5)
            # Sleep before the next iteration.
            log.info(
                "%s: engine sleeping for %.1f seconds", self.eqe.config_name, stime
            )
        self.schedule_next_message()

    def run(self):
        while not self._stopping:
            self._connection = None
            self._published_messages_pending_ack_from_broker = {}
            self._acked = 0
            self._nacked = 0
            self._message_number = 0

            try:
                if not self._connection:
                    self._connection = self.connect()
                self.schedule_next_message()
                self._connection.ioloop.start()
            except KeyboardInterrupt:
                self.stop()
                if self._connection is not None and not self._connection.is_closed:
                    # Finish closing
                    self._connection.ioloop.start()

        log.info("Stopped")

    def stop(self):
        """Stop the example by closing the channel and connection. We
        set a flag here so that we stop scheduling new messages to be
        published. The IOLoop is started because this method is
        invoked by the Try/Catch below when KeyboardInterrupt is caught.
        Starting the IOLoop again will allow the publisher to cleanly
        disconnect from RabbitMQ.
        """
        log.info("Stopping")
        self._stopping = True
        self.close_channel()
        self.close_connection()

    def close_channel(self):
        """Invoke this command to close the channel with RabbitMQ by sending
        the Channel.Close RPC command.
        """
        if self.pub_channel is not None:
            log.info("Closing the publish channel")
            self.pub_channel.close()
        if self.sub_channel is not None:
            log.info("Closing the subscribe channel")
            self.sub_channel.close()

    def close_connection(self):
        """This method closes the connection to RabbitMQ."""
        if self._connection is not None:
            log.info("Closing connection")
            self._connection.close()
