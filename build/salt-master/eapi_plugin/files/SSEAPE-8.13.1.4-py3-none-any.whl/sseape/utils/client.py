# coding: utf-8
"""
RaaS client utils
"""

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
from __future__ import absolute_import
import logging
import os

# Import 3rd-party libs
from sseapiclient import APIClient
from sseapiclient.httpclient import HTTPClient

# Import SSEAPE libs
import sseape.utils.config as sseape_config

log = logging.getLogger(__name__)


def _get_client_kwargs(opts, rpc_api_version=None, pillar=None):
    pillar = pillar or {}
    username = opts.get("sseapi_username", None) or opts["id"]
    timeout = opts.get("sseapi_timeout", 200)
    ssl_validate_cert = opts.get(
        "sseapi_ssl_validate_cert",
        # Support the old setting value
        opts.get("sseapi_validate_cert", True),
    )
    csp_pillar_key = opts.get("sseapi_csp_pillar", "CSP_AUTH_TOKEN")
    csp_pillar = pillar.get(csp_pillar_key, {})
    csp_url = csp_pillar.get("csp_url", pillar.get("csp_url", None))
    csp_org_id = csp_pillar.get("csp_org_id", pillar.get("csp_org_id", None))
    csp_client_id = csp_pillar.get("csp_client_id", pillar.get("csp_client_id", None))
    csp_client_secret = csp_pillar.get(
        "csp_client_secret", pillar.get("csp_client_secret", None)
    )

    kwargs = {
        "server": sseape_config.get(opts, "sseapi_server"),
        "username": username,
        "password": opts.get("sseapi_password", None),
        "config_name": opts.get("sseapi_config_name", "internal"),
        "csp_url": csp_url,
        "csp_org_id": csp_org_id,
        "csp_client_id": csp_client_id,
        "csp_client_secret": csp_client_secret,
        "timeout": timeout,
        "master_id": opts["id"],
        "cookies_path": os.path.join(opts["cachedir"], "sse-client.cookies"),
        "rpc_api_version": rpc_api_version,
        "ssl_key": opts.get("sseapi_ssl_key", None),
        "ssl_cert": opts.get("sseapi_ssl_cert", None),
        "ssl_validate_cert": ssl_validate_cert,
    }

    if not kwargs["password"]:
        kwargs["pubkey_path"] = sseape_config.get(opts, "sseapi_pubkey_path")

    return kwargs


def make_http_client(opts, rpc_api_version=None, pillar=None):
    kwargs = _get_client_kwargs(opts, rpc_api_version=rpc_api_version, pillar=pillar)
    return HTTPClient(**kwargs)


def make_api_client(opts, rpc_api_version=None, pillar=None):
    kwargs = _get_client_kwargs(opts, rpc_api_version=rpc_api_version, pillar=pillar)
    return APIClient(**kwargs)


def get_pillar(opts=None, runners=None, mods=None, pillar=None):
    ret = {}
    saltenv = opts.get("sseapi_csp_pillar_env", "base")
    csp_pillar = opts.get("sseapi_csp_pillar")
    if csp_pillar:
        if runners:
            pillar = runners["pillar.show_pillar"](
                minion=opts["id"], saltenv=saltenv, pillarenv=saltenv
            )
        elif mods:
            pillar = mods["pillar.items"](saltenv=saltenv, pillarenv=saltenv)
    if pillar:
        ret = dict(pillar.get(csp_pillar) or {})
    return ret
