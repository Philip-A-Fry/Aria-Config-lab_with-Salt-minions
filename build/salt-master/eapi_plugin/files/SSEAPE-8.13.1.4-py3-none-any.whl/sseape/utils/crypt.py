# -*- coding: utf-8 -*-

# Import python libs
import json
import logging
import os

# Import 3rd-party libs
from Cryptodome.Cipher import AES

log = logging.getLogger(__name__)


class SymmetricCipher:
    """
    Symmetric cipher base class
    """

    cipher_name = None
    prefix = None

    @classmethod
    def create_cipher(cls, opts, cipher_name=None, prefix=None):
        """
        Create a cipher by name or data prefix
        """
        if cipher_name:
            for subclass in cls.__subclasses__():
                if cipher_name == subclass.cipher_name:
                    return subclass(opts)
            raise ValueError("Invalid cipher name")
        if prefix:
            for subclass in cls.__subclasses__():
                if prefix == subclass.prefix:
                    return subclass(opts)
            raise ValueError("Invalid cipher prefix")
        return AES256Cipher(opts)

    @classmethod
    def get_prefix(cls, data):
        """
        Look for a cipher prefix in data
        """
        for subclass in cls.__subclasses__():
            if data.startswith(subclass.prefix):
                return subclass.prefix
        return None

    def __init__(self, opts):
        self.opts = opts

    def _get_key_path(self):
        return os.path.join(self.opts["pki_dir"], "sseapi_local_cache.key")

    def generate_key(self):
        """
        If the symmetric key does not exist, generate it and save it to the
        filesystem
        """
        key_path = self._get_key_path()
        if not os.path.exists(key_path):
            parent = os.path.dirname(key_path)
            os.makedirs(parent, exist_ok=True)
            os.chmod(parent, 0o700)
            key = {"priv": os.urandom(32).hex()}
            old_umask = os.umask(0o077)  # accessible only to owner
            with open(key_path, "wt") as f:
                f.write(json.dumps(key))
            os.umask(old_umask)
            log.info("Saved symmetric key to filesystem")
        else:
            log.info("Symmetric key exists, will not generate a new one")

    def get_key(self):
        """
        Get the symmetric key as bytes. If the key doesn't exist, generate it.
        """
        key_path = self._get_key_path()
        if not os.path.exists(key_path):
            self.generate_key()
        with open(key_path, "rt") as f:
            ser = f.read(128)
        key_struct = json.loads(ser)
        log.debug("Read key from filesystem")
        return bytes.fromhex(key_struct["priv"])

    def encrypt(self, data):
        raise NotImplementedError()

    def decrypt(self, data):
        """
        Decrypt data using a derived class cipher
        """
        prefix = SymmetricCipher.get_prefix(data)
        cipher = SymmetricCipher.create_cipher(self.opts, prefix=prefix)
        return cipher.decrypt(data)


class AES256Cipher(SymmetricCipher):
    """
    A FIPS-friendly AES-256-CTR cipher
    """

    cipher_name = "aes256"
    prefix = b"aes256:"
    nonce_size = 8

    def _get_cipher(self, nonce=None):
        """
        Create a cipher object
        """
        key = self.get_key()
        if nonce is None:
            nonce = os.urandom(self.nonce_size)
        cipher = AES.new(key, AES.MODE_CTR, nonce=nonce)
        return cipher, nonce

    def encrypt(self, data):
        """
        Encrypt data using the raas symmetric key
        """
        cipher, nonce = self._get_cipher()
        return self.prefix + nonce + cipher.encrypt(data)

    def decrypt(self, data):
        """
        Decrypt data using the raas symmetric key
        """
        if not data.startswith(self.prefix):
            raise ValueError("Cipher mismatch")
        data = data[len(self.prefix) :]
        nonce = data[0 : self.nonce_size]
        cipher, _ = self._get_cipher(nonce)
        return cipher.decrypt(data[len(nonce) :])
