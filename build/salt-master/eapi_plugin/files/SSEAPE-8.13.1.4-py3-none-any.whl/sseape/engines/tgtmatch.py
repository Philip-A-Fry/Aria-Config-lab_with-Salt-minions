# coding: utf-8
"""
The SSE Target Match engine

Get target groups from raas and calculate and cache minion matches
"""

# Import Python libs
from __future__ import absolute_import
import fnmatch
import functools
import hashlib
import json
import logging
import multiprocessing
import os
import time

# Import Salt libs
import salt.cache
import salt.config
import salt.serializers.msgpack as msgpack
import salt.syspaths
import salt.utils.event
from salt.exceptions import CommandExecutionError
from salt.serializers import DeserializationError, SerializationError

# Import SSEAPE libs
import sseape.utils.client
import sseape.utils.config as sseape_config
import sseape.utils.json
from sseapiclient.exc import NotConnectable, RPCError

MINION_NEW_JOB_EVENT_MATCH = "salt/job/*/new"
ALL_MINIONS_UUID = "7f93b928-388b-11e6-b133-346895ecb8f3"
WORKER_CHUNK_SIZE = 1000
DEFAULT_MAX_WORKERS = 8

__virtualname__ = "tgtmatch"
log = logging.getLogger(__name__)


def __virtual__():
    if "__role" not in __opts__:
        return False, "Unable to determine the role (master or minion)"
    if __opts__["__role"] != "master":
        return (
            False,
            "This engine is meant to run on the salt-master, not on {0}".format(
                __opts__["__role"]
            ),
        )
    return True


class MinionListCache(salt.cache.Cache):
    def __init__(self, opts, minions=None):
        super().__init__(opts)
        self.minions = minions

    def list(self, bank):
        if bank == "minions" and self.minions is not None:
            return self.minions
        return super().list(bank)


class MinionListCkMinions(salt.utils.minions.CkMinions):
    def __init__(self, opts, minions=None):
        super().__init__(opts)
        self.minions = minions
        self.cache = MinionListCache(opts, minions=self.minions)

    def _pki_minions(self):
        if self.minions is not None:
            return self.minions
        return super()._pki_minions()


class TargetMatchEngine:
    def __init__(self, opts=None, raas_client=None):
        self.opts = opts
        self.raas_client = raas_client
        self.salt_cache = salt.cache.factory(self.opts)

        # Make a list of target group master expressions that match this master
        self.master_match = ["*", self.opts["id"]]
        if self.opts.get("sseapi_cluster_id"):
            self.master_match.append(self.opts["sseapi_cluster_id"])

        self.poll_interval = max(
            sseape_config.get(self.opts, "sseapi_tgt_match.poll_interval"), 10
        )

        self._create_workers()
        self._setup_events()

    def __del__(self):
        try:
            self.workers.terminate()
            self.workers.join()
        except:  # pylint: disable=bare-except
            pass

    def _create_workers(self):
        """
        Create the target matching worker pool
        """
        procs = sseape_config.get(self.opts, "sseapi_tgt_match.workers")
        if procs <= 0:
            procs = min(DEFAULT_MAX_WORKERS, os.cpu_count())
        niceness = sseape_config.get(self.opts, "sseapi_tgt_match.nice")
        log.info("Creating %s workers with niceness %s", procs, niceness)
        self.workers = multiprocessing.Pool(
            processes=procs, initializer=os.nice, initargs=(niceness,)
        )

    def _setup_events(self):
        """
        Get a connection to the event bus and subscribe to new job events
        """
        self.event_bus = salt.utils.event.get_master_event(
            self.opts, self.opts["sock_dir"], listen=True
        )
        self.event_bus.subscribe(MINION_NEW_JOB_EVENT_MATCH)

    def _wait_and_handle_events(self, wait_time):
        """
        Wait and watch events for a specified time. If a pillar refresh
        happens, flush the pillar cache.
        """
        now = time.time()
        end_time = now + wait_time
        flushed = False
        while now < end_time:
            event = self.event_bus.get_event(wait=end_time - now, full=True)
            if (
                not flushed
                and event is not None
                and fnmatch.fnmatch(event["tag"], MINION_NEW_JOB_EVENT_MATCH)
                and event["data"]["fun"] == "saltutil.refresh_pillar"
            ):
                try:
                    log.debug("Pillar refresh, flushing local cache")
                    __salt__["sseapi_local_cache.flush"](cache="pillar")
                    flushed = True
                except CommandExecutionError as exc:
                    log.debug("Pillar cache flush failed: %s", exc)
            now = time.time()

    def _get_minion_expr_matches(self):
        """
        Get minion expr match data from local cache plus updates from current
        minion data
        """
        log.info("Reading minion expr matches from local cache")
        try:
            ret = __salt__["sseapi_local_cache.get_many"](cache="exprmatch", keypat="%")
            expr_matches = {key: msgpack.deserialize(val) for (key, val) in ret}
            log.debug(
                "Read expr matches for %s minions from local cache", len(expr_matches)
            )
        except (CommandExecutionError, DeserializationError) as exc:
            log.error(
                "Failed to read expr matches from local cache: %s",
                str(exc),
            )

        log.info("Updating minion data hashes")
        ret = {}
        minions = 0
        reset = 0
        reused = 0
        for minion in self.salt_cache.list("minions"):
            minions += 1
            bank = "minions/{}".format(minion)
            mtime = self.salt_cache.updated(bank, "data")
            if expr_matches.get(minion, {}).get("mtime", 0) == mtime:
                continue
            mdata = self.salt_cache.fetch(bank, "data")
            hash_data = {
                "grains": sseape.utils.json.sanitize_bytes(mdata.get("grains")),
                "pillar": sseape.utils.json.sanitize_bytes(mdata.get("pillar")),
            }
            hashable = json.dumps(hash_data, cls=sseape.utils.json.JSONEncoder).encode(
                "utf-8"
            )
            curhash = hashlib.sha256(hashable).hexdigest()
            if minion not in expr_matches or expr_matches[minion]["hash"] != curhash:
                expr_matches[minion] = {"mtime": mtime, "hash": curhash, "expr": {}}
                reset += 1
            else:
                reused += 1
        log.debug(
            "Expr matches for %s minions: %s reset, %s reused", minions, reset, reused
        )
        return expr_matches

    def _get_target_groups(self):
        """
        Get current target groups from raas. Return None if the call to get
        target groups failed.
        """
        log.info("Getting target groups from server")

        current_tgs = {}
        page = 0
        while True:
            try:
                ret = self.raas_client.api.tgt.get_target_group(
                    page=page, limit=100
                ).ret
                if ret["results"]:
                    for tg in ret["results"]:
                        if tg["uuid"] == ALL_MINIONS_UUID:
                            continue
                        try:
                            for master in tg["tgt"]:
                                if master in self.master_match:
                                    current_tgs[tg["uuid"]] = {
                                        "uuid": tg["uuid"],
                                        "tgt": tg["tgt"],
                                        "pillars": tg["pillars"],
                                    }
                                    break
                        except KeyError:
                            log.debug("Ignoring malformed target group: %s", tg)
                    page += 1
                else:
                    log.info("Got %s target groups from server", len(current_tgs))
                    break
            except (NotConnectable, RPCError) as exc:
                log.error("Failed to get target groups: %s", str(exc))
                return None

        # Save target groups to the local cache for use by the pillar plugin
        try:
            __salt__["sseapi_local_cache.flush"](cache="tgt")
            items = [
                (key, msgpack.serialize(val)) for (key, val) in current_tgs.items()
            ]
            if items:
                __salt__["sseapi_local_cache.set_many"](cache="tgt", items=items)
                log.debug("Saved %s target groups to local cache", len(items))
        except (CommandExecutionError, SerializationError) as exc:
            log.error(
                "Failed to save target groups to local cache: %s",
                str(exc),
            )

        return current_tgs

    def _match_target_group_cached(self, tgt_group, expr_matches):
        """
        Try to match all minions against a single target group using only
        cached match results (expr_matches). Return the set of matching minions
        and a list of minions that still need to be matched (matching result
        unknown).
        """
        log.debug("Target group %s: finding cached expr matches", tgt_group["uuid"])
        matching_minions = set()
        unknown_minions = []
        tgt = tgt_group["tgt"]

        hits = 0
        for minion in self.salt_cache.list("minions"):
            match = None
            for master in tgt:
                if master not in self.master_match:
                    continue
                expr_key = tgt[master]["tgt_type"] + ":" + tgt[master]["tgt"]
                this_match = expr_matches.get(minion, {}).get("expr", {}).get(expr_key)
                if this_match is not None and match is None:
                    match = this_match
                    hits += 1
                if match:
                    matching_minions.add(minion)
                    break
            if match is None:
                unknown_minions.append(minion)
        log.debug(
            "Target group %s: %s expr match cache hits, %s minions still to match",
            tgt_group["uuid"],
            hits,
            len(unknown_minions),
        )
        return matching_minions, unknown_minions

    @staticmethod
    def _match_target_group(opts, master_match, tgt_group, minions):
        """
        Match a list of minions against a single target group. Return the set
        of matching minions and data to save to the expr match cache. This
        routine is called by multiprocessing pool workers.
        """
        worker_start = time.time()
        log.debug(
            "Target group %s: matching %s minions",
            tgt_group["uuid"],
            len(minions),
        )
        matching_minions = set()
        expr_match_data = []
        tgt = tgt_group["tgt"]
        ck = MinionListCkMinions(opts, minions=minions)
        for master in tgt:
            if master not in master_match:
                continue
            ck_ret = ck.check_minions(
                expr=tgt[master]["tgt"],
                tgt_type=tgt[master]["tgt_type"],
                greedy=False,
            )
            matching_minions.update(ck_ret["minions"])
            # Collect expr match data to return
            expr_key = tgt[master]["tgt_type"] + ":" + tgt[master]["tgt"]
            expr_match_data.extend(
                [(minion, expr_key, True) for minion in ck_ret["minions"]]
            )
            non_matching = set(minions) - set(ck_ret["minions"])
            expr_match_data.extend(
                [(minion, expr_key, False) for minion in non_matching]
            )
        worker_end = time.time()
        log.debug(
            "Target group %s: matched %s of %s minions in %s sec",
            tgt_group["uuid"],
            len(matching_minions),
            len(minions),
            worker_end - worker_start,
        )
        return matching_minions, expr_match_data

    def _report_match_data(self, tgt_group, minions):
        """
        Send target group match data to raas
        """
        log.info(
            "Reporting %s matches for target group %s",
            len(minions),
            tgt_group["uuid"],
        )
        # Since there's no guarantee what data raas has, don't try to calculate
        # deltas. Just send the whole list and let raas (actually Postgres)
        # sort out the changes.
        try:
            self.raas_client.api.master.update_target_group_from_master(
                master_id=self.opts["id"],
                cluster_id=self.opts.get("cluster_id"),
                tgt_uuid=tgt_group["uuid"],
                minions_added=list(minions),
                minions_deleted=[],
                canonical_list=True,
            )
            log.debug("Reported matches for target group %s", tgt_group["uuid"])
        except (NotConnectable, RPCError) as exc:
            log.error(
                "Failed to report matches for target group %s: %s",
                tgt_group["uuid"],
                str(exc),
            )

    def _update_tgtmatch_cache(self, tgt_group, minions):
        """
        Update the local cache of match data for a target group
        """
        uuid = tgt_group["uuid"]
        null = msgpack.serialize(None)  # pylint: disable=assignment-from-no-return
        try:
            __salt__["sseapi_local_cache.flush"](cache="tgtmatch", keypat=f"{uuid}:%")
            items = [(f"{uuid}:{minion}", null) for minion in minions]
            if items:
                __salt__["sseapi_local_cache.set_many"](cache="tgtmatch", items=items)
                log.debug("Saved %s matches to local cache", len(items))
        except CommandExecutionError as exc:
            log.error(
                "Failed to save target group matches to local cache: %s",
                str(exc),
            )

    def _update_exprmatch_cache(self, expr_matches):
        """
        Update the local cache of expr matches
        """
        try:
            __salt__["sseapi_local_cache.flush"](cache="exprmatch")
            items = [
                (key, msgpack.serialize(val)) for (key, val) in expr_matches.items()
            ]
            if items:
                __salt__["sseapi_local_cache.set_many"](cache="exprmatch", items=items)
                log.debug(
                    "Saved expr matches for %s minions to local cache", len(items)
                )
        except (CommandExecutionError, SerializationError) as exc:
            log.error(
                "Failed to save expr matches to local cache: %s",
                str(exc),
            )

    def _match_target_groups(self, tgt_groups):
        """
        Match minions against a set of target groups. Report the results to
        raas and save to local caches.
        """
        expr_matches = self._get_minion_expr_matches()
        match_start = time.time()
        for tg in tgt_groups.values():
            tgt_start = time.time()
            log.debug("Target group %s: start matching", tg["uuid"])
            matching_minions, unknown_minions = self._match_target_group_cached(
                tg, expr_matches
            )
            if unknown_minions:
                chunks = [
                    unknown_minions[i : i + WORKER_CHUNK_SIZE]
                    for i in range(0, len(unknown_minions), WORKER_CHUNK_SIZE)
                ]
                for matches, exprs in self.workers.imap(
                    functools.partial(
                        self._match_target_group,
                        self.opts,
                        self.master_match,
                        tg,
                    ),
                    chunks,
                ):
                    matching_minions |= matches
                    for minion, expr_key, result in exprs:
                        expr_matches[minion]["expr"][expr_key] = result
            tgt_end = time.time()
            log.debug(
                "Target group %s: matching took %s sec",
                tg["uuid"],
                tgt_end - tgt_start,
            )
            self._report_match_data(tg, matching_minions)
            self._update_tgtmatch_cache(tg, matching_minions)
        match_end = time.time()
        log.info(
            "Matched %s target groups in %s sec",
            len(tgt_groups),
            match_end - match_start,
        )
        self._update_exprmatch_cache(expr_matches)

    def start(self):
        """
        Engine main loop
        """
        wait_time = self.poll_interval
        while True:
            self._wait_and_handle_events(wait_time)
            log.info("Start iteration")
            iteration_start = time.time()
            try:
                if self.raas_client is None:
                    pillar = sseape.utils.client.get_pillar(
                        opts=self.opts, runners=__runners__
                    )
                    self.raas_client = sseape.utils.client.make_api_client(
                        opts=self.opts, pillar=pillar
                    )
                tgt_groups = self._get_target_groups()
                if tgt_groups is None:
                    log.info("Failed to get target groups, skipping iteration")
                    time.sleep(self.poll_interval)
                    continue
                self._match_target_groups(tgt_groups)
            except Exception as exc:  # pylint: disable=broad-except
                log.error(
                    "Iteration interrupted with exception: %s", exc, exc_info=True
                )
            iteration_end = time.time()
            duration = iteration_end - iteration_start
            wait_time = max(self.poll_interval - duration, self.poll_interval / 5)
            log.info(
                "End iteration (%s seconds), waiting for %s seconds",
                duration,
                wait_time,
            )


def start(raas_client=None):
    """
    Start the engine
    """
    opts = globals().get("__opts__")
    if opts is None:
        opts = salt.config.master_config(
            os.path.join(salt.syspaths.CONFIG_DIR, "master")
        )

    TargetMatchEngine(opts, raas_client).start()
