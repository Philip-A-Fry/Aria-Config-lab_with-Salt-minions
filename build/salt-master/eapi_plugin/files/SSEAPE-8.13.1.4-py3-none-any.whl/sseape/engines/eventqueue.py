# coding: utf-8
"""
The SSE Event Queue engine

Periodically get events from the local event queue and send them to raas
via a call to `event_save` in the raas client OR to the RMQ bus.

To enable the RMQ sink, in /etc/salt/master.d/raas.conf set the following.
Note that the names of the publish and subscribe exchanges can be anything
but need to be the same unless you have a very unusual setup for RabbitMQ.

sseapi_event_queue:
  event_sink: rmq
  amqp_url: amqp://username:password@rabbithost:5672
  amqp_publish_exchange: salt
  amqp_subscribe_exchange: salt
  strategy: always

event_sink must be set to 'rmq' and strategy must be set to 'always' for
events to be shipped to RMQ.

When the RMQ sink is enabled, all masters will see all events.
However, at this time, jobs submitted by one master will not be executed
by other masters.  We will continue to rely on vSSC's intelligence to submit
jobs to all connected masters.

To maintain parity with the ZeroMQ bus, if there are no masters running,
any events published to Rabbit will be dropped.  If there is one master running
events get published into the exchange and sent to any connected queues, but
the only events on the bus will be the ones that the single master published,
and it will drop those events to avoid infinite event publishing loops.
"""

# Import Python libs
from __future__ import absolute_import
import logging
import os

# Import Salt libs
import salt.config
import salt.loader
import salt.syspaths

# Import SSEAPE libs
from sseape.utils.client import get_pillar
from sseape.utils.engine import QueueEngineBase
import sseape.utils.config as sseape_config

__virtualname__ = "eventqueue"
log = logging.getLogger(__name__)

HAS_PIKA = True
try:
    from sseape.utils.rmq import SaltRMQPubsub
except ModuleNotFoundError:
    # This is an assumption, the most likely reason we can't import sseape.utils.rmq is that
    # pika wasn't installed.  There might be other reasons.
    log.info(
        "Cannot load the RMQ transport adapter.  The Pika AMQP/RabbitMQ library may not be available.  Cannot use RMQ transport."
    )
    HAS_PIKA = False


def __virtual__():
    if "__role" not in __opts__:
        return (
            False,
            "SSE Local Event Queue not enabled: Unable to find out the role (master or minion)",
        )
    if __opts__["__role"] != "master":
        return (
            False,
            "SSE Local Event Queue is disabled: The Local SSE Event Queue engine runs on the salt-master "
            "but this appears to be a {0}.".format(__opts__["__role"]),
        )

    # Do some sanity checking on the event queue settings
    # If sseapi_event_queue.event_sink is "rpc" then
    # .strategy can be "always" or "on_failure"
    # If .event_sink is "rmq" then .strategy has to be "always"
    # and we need values for .amqp_url, .amqp_publish_exchange, .amqp_subscribe_exchange

    if (
        "sseapi_event_queue" in __opts__
        and __opts__["sseapi_event_queue"].get("strategy") == "on_failure"
    ):
        if __opts__["sseapi_event_queue"].get("event_sink") == "rmq":
            return (
                False,
                'SSE Local Event Queue is disabled: Sending events to RMQ requires sseapi_event_queue.strategy of "always"',
            )
    if "sseapi_event_queue" in __opts__ and __opts__["sseapi_event_queue"].get(
        "strategy"
    ) not in ("always", "on_failure"):
        return (
            False,
            'SSE Local Event queue not enabled: strategy must be "always" or "on_failure"',
        )
    if (
        "sseapi_event_queue" in __opts__
        and __opts__["sseapi_event_queue"].get("event_sink") == "rmq"
    ):
        if not all(
            [
                __opts__["sseapi_event_queue"].get("amqp_url", False),
                __opts__["sseapi_event_queue"].get("amqp_publish_exchange", False),
                __opts__["sseapi_event_queue"].get("amqp_subscribe_exchange", False),
            ]
        ):
            return (
                False,
                'SSE Local Event queue not enabled: event_sink is "rmq" but one or more of "amqp_url", "amqp_publish_exchange", "amqp_subscribe_exchange" not set.',
            )
    return True


class EventQueueEngine(QueueEngineBase):
    def __init__(
        self, config_name=None, opts=None, raas_client=None, returners=None, pillar=None
    ):
        super(EventQueueEngine, self).__init__(
            config_name="sseapi_event_queue",
            opts=opts,
            raas_client=raas_client,
            pillar=pillar,
        )

        if returners is None:
            self.returners = salt.loader.returners(self.opts, __salt__)
        else:
            self.returners = returners

    def send_entries(self, entries):
        """
        Send events to raas. Base class handles exceptions.
        """
        events = [item["data"] for item in entries]
        self.raas_client.api.ret.save_event(self.opts["id"], events)

        # Return the timestamp of the newest successfully pushed entry
        return max([item["timestamp"] for item in entries])

    def forward_entries(self, queue, entries):
        """
        Send events to a "forwarding" returner. Base class handles exceptions.
        """
        events = [item["data"] for item in entries]
        event_return = "{}.event_return".format(queue)
        if event_return in self.returners:
            try:
                log.info("Forwarding %d entries to %s", len(events), event_return)
                self.returners[event_return](events)
            except Exception as exc:  # pylint: disable=broad-except
                log.error(
                    "Could not forward entries: %s raised an exception: %s",
                    event_return,
                    exc,
                )
                raise
        else:
            log.error("Could not forward entries: %s not found", event_return)


class RMQEngine(EventQueueEngine):
    def __init__(
        self, config_name=None, opts=None, returners=None, io_loop=None, pillar=None
    ):
        super(RMQEngine, self).__init__(
            config_name="sseapi_event_queue", opts=opts, pillar=pillar
        )

        # Connect to RMQ here
        if returners is None:
            self.returners = salt.loader.returners(self.opts, __salt__)
        else:
            self.returners = returners

        self.rmq = SaltRMQPubsub(opts=self.opts, io_loop=io_loop, eqe=self)

    def send_entries(self, entries):
        return self.rmq.send_entries(entries)

    def start(self):
        log.info("rmq--Starting RMQ connection")
        self.rmq.run()


def start(raas_client=None, returners=None):
    """
    Start the engine
    """
    opts = globals().get("__opts__")
    if opts is None:
        opts = salt.config.master_config(
            os.path.join(salt.syspaths.CONFIG_DIR, "master")
        )
    pillar = get_pillar(opts=opts, runners=__runners__)
    if HAS_PIKA and sseape_config.get(opts, "sseapi_event_queue.event_sink") == "rmq":
        log.info("Starting the zeromq-rmq engine bridge")
        RMQEngine(opts=opts, returners=returners, pillar=pillar).start()
    else:
        log.info("Starting the event queueing engine.")
        EventQueueEngine(
            opts=opts, raas_client=raas_client, returners=returners, pillar=pillar
        ).start()
