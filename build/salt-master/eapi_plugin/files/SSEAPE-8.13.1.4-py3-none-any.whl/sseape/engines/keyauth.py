# coding: utf-8
"""
The Key Auth engine

Manage keys for authenticating a salt-master to raas
"""

from __future__ import absolute_import
import logging
import os
import time

import salt.config
import salt.syspaths

import sseape.utils.client
from sseapiclient.exc import NotConnectable

__virtualname__ = "keyauth"
log = logging.getLogger(__name__)


def __virtual__():
    if "__role" not in __opts__:
        return False, "Unable to find out the role (master or minion)"
    if __opts__["__role"] != "master":
        return (
            False,
            "The Key Auth engine is meant to run on the salt-master, "
            "not on {0}".format(__opts__["__role"]),
        )
    if "sseapi_password" in __opts__:
        return False, "Master key authentication disabled: sseapi_password is set"
    if "sseapi_pubkey_path" not in __opts__:
        return (
            False,
            "Master key authentication disabled: sseapi_pubkey_path is not set",
        )
    return True


class KeyAuthEngine:
    def __init__(self, opts=None, raas_client=None):
        self.opts = opts
        self.raas_client = raas_client
        self.pubkey_path = opts["sseapi_pubkey_path"]
        self.engine_interval = opts.get("sseapi_key_check", 300)
        self.key_rotation_interval = opts.get("sseapi_key_rotation", 24 * 3600)

    def start(self):
        """
        Engine main loop
        """
        while True:
            log.info("%s engine: starting iteration", __virtualname__)

            if self.raas_client is None:
                try:
                    pillar = sseape.utils.client.get_pillar(
                        runners=__runners__, opts=self.opts
                    )
                    self.raas_client = sseape.utils.client.make_http_client(
                        opts=self.opts, pillar=pillar
                    )
                except NotConnectable as exc:
                    log.debug(
                        "%s engine: could not connect to SSE server: %s",
                        __virtualname__,
                        exc,
                    )
                    time.sleep(self.engine_interval)
                    continue

            start = time.time()

            try:
                key_stat = os.stat(self.pubkey_path)
            except OSError as exc:
                log.info(
                    "%s engine: skipping auth key rotation: %s", __virtualname__, exc
                )
                key_stat = None

            try:
                if key_stat and start - key_stat.st_mtime > self.key_rotation_interval:
                    self.raas_client.rotate_master_key()
            except Exception as exc:  # pylint: disable=broad-except
                log.error(
                    "%s engine: failed to rotate auth key: %s", __virtualname__, exc
                )

            duration = time.time() - start
            # If the iteration ran longer than the interval, sleep a little anyway
            stime = self.engine_interval - duration
            if stime < 0:
                log.warning(
                    "%s engine: iteration time (%.1fs) exceeded interval (%.1fs)",
                    __virtualname__,
                    duration,
                    self.engine_interval,
                )
                stime = min(5, self.engine_interval / 5)

            # Sleep before the next iteration
            log.info("%s engine: sleeping for %.1f seconds", __virtualname__, stime)
            time.sleep(stime)


def start(raas_client=None):
    """
    Start the engine
    """
    opts = globals().get("__opts__")
    if opts is None:
        opts = salt.config.master_config(
            os.path.join(salt.syspaths.CONFIG_DIR, "master")
        )

    KeyAuthEngine(opts, raas_client).start()
