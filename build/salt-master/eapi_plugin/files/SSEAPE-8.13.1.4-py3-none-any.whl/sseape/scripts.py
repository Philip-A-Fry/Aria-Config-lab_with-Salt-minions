# -*- coding: utf-8 -*-
"""
    sseape.scripts
    ~~~~~~~~~~~~~~

    This will print out example configuration
"""

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
import argparse
import os
import sys

import sseape.utils.config as sseape_config
import sseape.version
from sseape.utils.csp import DEFAULT_CSP_URL
from sseape.utils.join import JoinSSC


class ShowVersion(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        print(
            "SSEAPE version {git_describe} {build_date}".format(
                **sseape.version.BUILDINFO
            )
        )
        sys.exit(0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--ext-modules",
        action="store_true",
        default=False,
        help="Print out the external extension modules directories settings",
    )
    parser.add_argument(
        "--default-config",
        action="store_true",
        default=False,
        help="Print out the default configuration settings",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        default=False,
        help="This is the same as passing --ext-modules and --default-config",
    )
    parser.add_argument(
        "--fileserver-update-interval",
        action="store",
        type=int,
        dest="fileserver_update_interval",
        default=60,
    )
    parser.add_argument(
        "--timeout", action="store", type=int, dest="timeout", default=15
    )
    parser.add_argument(
        "-l",
        "--log-level",
        action="store",
        dest="log_level",
        default="INFO",
        type=str.upper,
        help="log level for python logger",
    )
    parser.add_argument("--version", nargs=0, action=ShowVersion)

    sub_parsers = parser.add_subparsers(dest="command")
    parser_join = sub_parsers.add_parser(
        "join", help="Join this salt-master to the SaltStack Cloud instance"
    )
    parser_join.add_argument(
        "--ssc-url",
        action="store",
        dest="ssc_url",
        default="http://localhost:8080",
        help="SaltStack Cloud instance region-specific URL",
    )
    parser_join.add_argument(
        "--csp-url",
        action="store",
        default=DEFAULT_CSP_URL,  # prod
        dest="csp_url",
        help="VMware Cloud Services Portal (CSP) URL",
    )
    parser_join.add_argument(
        "--override-oauth-app",
        action="store_true",
        default=False,
        dest="override_oauth_app",
        help="Recreate OAuth app for this master if OAuth already exists.",
    )

    args = parser.parse_args()
    default_overrides = {
        "ext_modules": args.ext_modules or args.all,
        "default_config": args.default_config or args.all,
        "fs_update_interval": args.fileserver_update_interval,
        "timeout": args.timeout,
    }

    if args.command == "join":
        default_overrides["sseapi_server"] = args.ssc_url
        JoinSSC.run(
            csp_base_url=args.csp_url,
            log_level=args.log_level,
            override_oauth_app=args.override_oauth_app,
            **default_overrides
        )
    else:
        default_overrides["sseapi_pubkey_path"] = lambda master_opts: os.path.join(
            master_opts["pki_dir"], "sseapi_key.pub"
        )
        print(sseape_config.generate(**default_overrides))
    parser.exit(0)
